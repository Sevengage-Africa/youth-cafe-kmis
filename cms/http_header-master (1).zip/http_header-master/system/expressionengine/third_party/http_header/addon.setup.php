<?php

return array(
    'author'      => 'Rob Sanchez',
    'author_url'  => 'https://github.com/rsanchez',
    'name'        => 'HTTP Header',
    'description' => 'Set the HTTP Headers for your template.',
    'version'     => '1.1.2',
    'namespace'   => '\\',
);
