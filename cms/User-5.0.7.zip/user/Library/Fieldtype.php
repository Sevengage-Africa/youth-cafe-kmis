<?php

namespace Solspace\Addons\User\Library;
use Solspace\Addons\User\Library\AddonBuilder;

class Fieldtype extends AddonBuilder
{
}

// End class Fieldtype
