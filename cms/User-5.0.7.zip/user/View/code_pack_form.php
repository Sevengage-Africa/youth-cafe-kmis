<div class="<?=(isset($box_class) ? $box_class : '')?>">
	<?php $this->embed('ee:_shared/form')?>
</div>
