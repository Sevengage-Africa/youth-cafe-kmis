<p><strong><?=lang('screen_name')?></strong>: <?=$screen_name?></p>
<p><strong><?=lang('member_id')?></strong>: <?=$member_id?></p>
<p><strong><?=lang('username')?></strong>: <?=$username?></p>
<p><strong><?=lang('email')?></strong>: <?=$email?></p>