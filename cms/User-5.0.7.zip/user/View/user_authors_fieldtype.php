<div class="publish_textarea" id="solspace_user_browse_authors_hold" style="width: 100%; ">
	<div id="sub_hold_field_user__solspace_user_browse_authors">
		<fieldset class="holder">
			<textarea name="solspace_user_browse_authors" cols="90" rows="5" id="solspace_user_browse_authors" dir="ltr"><?=$assigned_authors?></textarea>
		</fieldset>
	</div>
	<!-- /sub_hold_field -->
</div>
<!-- /publish_field -->
<div class="publish_text" id="solspace_user_primary_author_hold" style="width: 100%; ">
	<div class="handle"></div>
	<label class="hide_field">
		<span>
			<?=lang('primary_author')?>
		</span>
	</label>
	<div id="sub_hold_field_user__solspace_user_primary_author">
		<fieldset class="holder">
			<input type="text" name="solspace_user_primary_author" value="<?=$primary_author?>" id="solspace_user_primary_author" dir="ltr" field_content_type="all" maxlength="400" /> </fieldset>
	</div>
	<!-- /sub_hold_field -->
</div>