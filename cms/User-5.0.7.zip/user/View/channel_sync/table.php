<table id="mapping-table">
	<thead>
		<tr>
			<th><?=lang('member_field')?></th>
			<th><?=lang('channel_field')?></th>
			<th style="width:20px;"></th>
		</tr>
	</thead>
	<tbody>

	</tbody>
</table>
<ul class="toolbar">
	<li id="add-mapping-row" class="add"><a href="#" title="add new row"></a></li>
</ul>