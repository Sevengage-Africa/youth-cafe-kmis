<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}


// include_once config file
include_once PATH_THIRD.'shortlist/config.php';
require_once PATH_THIRD.'shortlist/eeharbor.php';

/**
 * Shortlist Data Class
 *
 * @package         shortlist_ee_addon
 * @author          Tom Jaeger <Tom@EEHarbor.com>
 * @link            http://eeharbor.com/shortlist
 * @copyright       Copyright (c) 2016, Tom Jaeger/EEHarbor
 */


class Shortlist_data
{
    /**
     * Set preference
     *
     * @access	public
     * @return	array
     */

    public function set_preference($preferences = array(), $site_id = '1')
    {
        /** --------------------------------------------
        /**  Prep Cache, Return if Set
        /** --------------------------------------------*/

        $cache_name = __FUNCTION__;
        $cache_hash = $this->_imploder(func_get_args());

        if (isset($this->cached[$cache_name][$cache_hash])) {
            return $this->cached[$cache_name][$cache_hash];
        }

        $this->cached[$cache_name][$cache_hash] = array();

        /** --------------------------------------------
        /**	Grab prefs from DB
        /** --------------------------------------------*/

        if ($site_id == '') {
            $site_id = ee()->config->item('site_id');
        }

        $sql    = "SELECT site_system_preferences
					FROM exp_sites
					WHERE site_id = " . ee()->db->escape_str($site_id);

        $query    = ee()->db->query($sql);

        if ($query->num_rows() == 0) {
            return false;
        }

        ee()->load->helper('string');

        $this->cached[$cache_name][$cache_hash] = unserialize(base64_decode($query->row('site_system_preferences')));


        /** --------------------------------------------
        /**	Add our prefs
        /** --------------------------------------------*/

        $prefs    = array();

        foreach (explode("|", Shortlist_PREFERENCES) as $val) {
            if (isset($preferences[$val]) === true) {
                $this->cached[$cache_name][$cache_hash][$val]    = $preferences[$val];
            }
        }


        $prefs = base64_encode(serialize($this->cached[$cache_name][$cache_hash]));


        ee()->db->query(ee()->db->update_string(
                    'exp_sites',
                    array(
                        'site_system_preferences' => $prefs
                    ),
                    array(
                        'site_id'    => ee()->db->escape_str($site_id)
                    )
                )
            );

        return true;
    }

    /* End set preference */

    // --------------------------------------------------------------------

    /**
     * Repload Preferences
     *
     * @access	public
     * @return	array
     */

    public function reload_preferences()
    {
        /** --------------------------------------------
        /**  Prep Cache, Return if Set
        /** --------------------------------------------*/

        $cache_name = __FUNCTION__;
        $cache_hash = $this->_imploder(func_get_args());

        if (isset($this->cached[$cache_name][$cache_hash])) {
            return $this->cached[$cache_name][$cache_hash];
        }

        $this->cached[$cache_name][$cache_hash] = array();

        /** --------------------------------------------
        /**	Grab prefs from DB
        /** --------------------------------------------*/

        $sql    = "SELECT site_system_preferences
					FROM exp_sites
					WHERE site_id = " . ee()->db->escape_str(ee()->config->item('site_id'));

        $query    = ee()->db->query($sql);

        if ($query->num_rows() == 0) {
            return false;
        }

        ee()->load->helper('string');

        $this->cached[$cache_name][$cache_hash] = unserialize(base64_decode($query->row('site_system_preferences')));


        return $this->cached[$cache_name][$cache_hash];
    }

    /* End set preference */

    // --------------------------------------------------------------------
}

// End of file data.Shortlist.php
