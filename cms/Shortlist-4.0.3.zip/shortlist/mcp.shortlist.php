<?php defined('BASEPATH') or exit('No direct script access allowed');
require_once PATH_THIRD.'shortlist/eeharbor.php';

class Shortlist_mcp
{
    public $module_name;
    private $nocache;
    private $cache;

    private $overview_limit = 10;
    private $limit = 25;
    private $offset = 0;

    public function __construct()
    {
        $this->eeharbor = new \shortlist\EEHarbor;

        $this->module_name = strtolower(str_replace('_mcp', '', get_class($this)));
        $this->base = BASE;//str_replace( '&amp;D=', '&D=', BASE.'&C=addons_modules&M=show_module_cp&module=' . $this->module_name );
        $this->eeX = 'ee'.$this->eeharbor->getEEVersion(true);

        // Define the package path
        ee()->load->add_package_path(PATH_THIRD.'shortlist');
          // Load our helper
        ee()->load->helper('Shortlist_helper');
        ee()->lang->loadfile('shortlist');
        // Load base model
        if (!class_exists('Shortlist_model')) {
            ee()->load->library('Shortlist_model');
        }
        if (!isset(ee()->shortlist_core_model)) {
            Shortlist_model::load_models();
        }

        //ee()->load->remove_package_path(PATH_THIRD.'shortlist');
    }

    /**
     * Generates sidbar nav
     *
     * @method generateSidebar
     * @param  string $active Section that is active
     * @return sid bar navigation
     */
    private function generateSidebar()
    {
        $nav_items = array(
                    lang('shortlist')=>'',
                    lang('import')=>'extras',
                    lang('settings')=>'settings',
                );

        $this->eeharbor->getNav($nav_items);
    }

    public function index()
    {
        ee()->view->cp_page_title = lang('shortlist_module_name');

        $this->_add_morphine();

        $this->cache = array();
        // Get all the items

        $this->limit = $this->overview_limit;
        $this->offset = 0;

        $this->_get_lists();
        $this->_get_items();
        $this->_get_member_data();
        $this->_get_members();

        $this->cache['lists_uri'] = $this->eeharbor->moduleURL('view_lists');
        $this->cache['items_uri'] = $this->eeharbor->moduleURL('view_items');
        $this->cache['members_uri'] = $this->eeharbor->moduleURL('view_members');

        $this->_get_action_uris();

        return $this->eeharbor->view($this->eeX.'/mcp_index', $this->cache, true);
    }

    // --------------------------------------------------------------------

    public function extras()
    {
        ee()->view->cp_page_title = lang('shortlist_import_title');

        $this->_add_morphine();

        $this->cache = array();

        $this->cache['show_favorites_option'] = false;
        $this->cache['show_vc_todo_option'] = false;

        $this->cache['import_favs_uri'] = $this->eeharbor->moduleURL('import_favourites');
        $this->cache['import_custom_uri'] = $this->eeharbor->moduleURL('import_vc_todo');

        // Do we have favorites data?
        $f = ee()->db->query(" SHOW TABLES LIKE 'exp_favorites' ")->result_array();
        if (count($f) > 0) {
            $f_r = ee()->db->query(" SELECT COUNT(*) c FROM exp_favorites ")->row_array();
            if ($f_r['c'] > 0) {
                $this->cache['show_favorites_option'] = true;
            }
        }

        // Do we have vc_todo data?
        $f = ee()->db->query(" SHOW TABLES LIKE 'exp_vc_todo' ")->result_array();
        if (count($f) > 0) {
            $f_r = ee()->db->query(" SELECT COUNT(*) c FROM exp_vc_todo ")->row_array();
            if ($f_r['c'] > 0) {
                $this->cache['show_vc_todo_option'] = true;
            }
        }

        return  $this->eeharbor->view($this->eeX.'/mcp_extras', $this->cache, true);
    }

    // --------------------------------------------------------------------




    public function import_complete()
    {
        ee()->view->cp_page_title = lang('shortlist_import_complete_title');

        $this->_add_morphine();

        $this->cache = array();

        return  $this->eeharbor->view($this->eeX.'/mcp_import_complete', $this->cache, true);
    }

    // --------------------------------------------------------------------


    public function import_favourites()
    {
        ee()->view->cp_page_title = lang('shortlist_import_favourites');
        $this->_add_morphine();
        $this->cache = array();
        $this->cache['show_confirm'] = true;
        $this->cache['list_name'] = '';
        $this->cache['list_title'] = '';
        $this->cache['clear_table'] = 'yes';


        if (!empty($_POST)) {
            // Posted, handle;
            $this->cache['show_confirm'] = false;

            // Validate the passed data
            $required = array('list_title', 'list_name', 'clear_table');
            $data = array();
            $errors = array();
            foreach ($required as $req) {
                if (!isset($_POST[$req]) or $_POST[$req] == '') {
                    $errors[$req] = 'missing';
                } else {
                    $data[$req] = $_POST[$req];
                    $this->cache[$req] = $_POST[$req];
                }
            }

            if (empty($errors)) {
                // Good to go.
                $this->_import_from_favorites($data);
                return;
            }

            $this->cache['errors'] = $errors;
        }

        // Get some stats on the favourites data
        $this->cache['stats'] = $this->_get_stats_favourites();

        $this->cache['form_post_url'] = $this->eeharbor->moduleURL('import_favourites', array('act'=>'run'));

        return  $this->eeharbor->view($this->eeX.'/mcp_import_favourites', $this->cache, true);
    }
    // --------------------------------------------------------------------

    // --------------------------------------------------------------------


    public function import_vc_todo()
    {
        ee()->view->cp_page_title = lang('shortlist_import_vc_todo');
        $this->_add_morphine();
        $this->cache = array();
        $this->cache['show_confirm'] = true;
        $this->cache['list_name_todo'] = '';
        $this->cache['list_title_todo'] = '';

        $this->cache['list_title_done'] = '';
        $this->cache['list_name_done'] = '';

        $this->cache['clear_table'] = 'yes';


        if (!empty($_POST)) {
            // Posted, handle;
            $this->cache['show_confirm'] = false;

            // Validate the passed data
            $required = array('list_title_todo', 'list_name_todo', 'list_title_done', 'list_name_done', 'clear_table');
            $data = array();
            $errors = array();
            foreach ($required as $req) {
                if (!isset($_POST[$req]) or $_POST[$req] == '') {
                    $errors[$req] = 'missing';
                } else {
                    $data[$req] = $_POST[$req];
                    $this->cache[$req] = $_POST[$req];
                }
            }

            if (empty($errors)) {
                // Good to go.
                $this->_import_from_vc_todo($data);
                return;
            }

            $this->cache['errors'] = $errors;
        }

        // Get some stats on the favourites data
        $this->cache['stats'] = $this->_get_stats_vc_todo();

        $this->cache['form_post_url'] = $this->eeharbor->moduleURL('import_vc_todo', array('act'=>'run'));

        return  $this->eeharbor->view($this->eeX.'/mcp_import_vc_todo', $this->cache, true);
    }
    // --------------------------------------------------------------------


    public function view_list()
    {
        ee()->view->cp_page_title = lang('shortlist_list_page');

        ee()->cp->set_breadcrumb($this->eeharbor->moduleURL('index'), lang('shortlist_module_name'));
        $this->_add_morphine();

        // Get just this list

        $list_id = ee()->input->get('list_id');

        // If we dont have a list_id, things will fail. So redirect.
        if(!$list_id)
        {
            ee()->functions->redirect($this->eeharbor->moduleURL('index'));
        }

        $this->_get_lists($list_id);
        $this->_get_items_for_list($list_id);
        $this->_get_clones($list_id);
        $this->_get_members();
        $this->_get_member_data();
        $this->_get_action_uris('view_list');


        return  $this->eeharbor->view($this->eeX.'/mcp_list', $this->cache, true);
    }

    // --------------------------------------------------------------------

    public function view_item()
    {
        $entry_id = ee()->input->get('entry_id');

        if (empty($entry_id)) {
            $this->eeharbor->flashData('message_error', 'Item does not exist.');
            ee()->functions->redirect($this->eeharbor->moduleURL('view_items'));
        }

        ee()->view->cp_page_title = lang('shortlist_item_page');

        ee()->cp->set_breadcrumb($this->eeharbor->moduleURL('index'), lang('shortlist_module_name'));
        $this->_add_morphine();

        $this->cache = array();

        $this->_get_items($entry_id);
        $this->_get_lists_with_entry($entry_id);
        $this->_get_member_data();
        $this->_get_members();
        $this->_get_action_uris();

        if ($this->cache['item_count'] == '0') {
            // $this->eeharbor->flashData('message_notice', 'The requested item does not exist.');
            ee()->functions->redirect($this->eeharbor->moduleURL('view_items'));
        }

        return  $this->eeharbor->view($this->eeX.'/mcp_item', $this->cache, true);
    }

    // --------------------------------------------------------------------

    public function view_items()
    {
        ee()->view->cp_page_title = lang('shortlist_item_page');

        ee()->cp->set_breadcrumb($this->eeharbor->moduleURL('index'), lang('shortlist_module_name'));
        $this->_add_morphine();

        $total = ee()->shortlist_item_model->count_all();
        $this->offset = $this->_pagination($total, 'view_items');

        $this->_get_items();

        $this->_get_action_uris();
        return  $this->eeharbor->view($this->eeX.'/mcp_items', $this->cache, true);
    }


    // --------------------------------------------------------------------

    public function view_members()
    {
        ee()->view->cp_page_title = lang('shortlist_member_page');

        ee()->cp->set_breadcrumb($this->eeharbor->moduleURL('index'), lang('shortlist_module_name'));
        $this->_add_morphine();

        // MySQL 5.7.5 workaround. TODO: Come back to this and rewrite these queries.
        ee()->db->query("SET SESSION sql_mode = ''");

        // Also pull all the members for our lists
        $count = ee()->db->select('count(*) c')
                    ->from('shortlist_list')
                    ->group_by('member_id, session_id')
                    ->where('member_id != "0"')
                    ->or_where('session_id != ""')
                    ->get()
                    ->result_array();

        $total = count($count);
        $this->offset = $this->_pagination($total, 'view_members');

        $this->_get_lists();
        $this->_get_members();
        $this->_get_member_data();

        $this->cache['member_count'] = $total;

        $this->_get_action_uris();
        return  $this->eeharbor->view($this->eeX.'/mcp_members', $this->cache, true);
    }


    // --------------------------------------------------------------------

    public function view_member()
    {
        ee()->view->cp_page_title = lang('shortlist_member_page');

        ee()->cp->set_breadcrumb($this->eeharbor->moduleURL('index'), lang('shortlist_module_name'));
        $this->_add_morphine();

        // member_id or session_id.
        $type = '';
        $id = '';

        $member_id = ee()->input->get('member_id');
        $session_id = ee()->input->get('session_id');
        if ($member_id != '') {
            $type = 'member_id';
            $id = $member_id;
            $this->cache['member_data'][ $id ] = array();
        } elseif ($session_id != '') {
            $type = 'session_id';
            $id = $session_id;
        }

        if ($type == '') {
            ee()->functions->redirect($this->eeharbor->moduleURL('view_members'));
        }

        // Get this member's things
        $this->_get_lists_for_member($id, $type);
        $this->_get_member_data();

        $this->cache['user_id'] = $id;
        $this->cache['user_type'] = $type;


        $this->_get_action_uris();
        return  $this->eeharbor->view($this->eeX.'/mcp_member', $this->cache, true);
    }


    // --------------------------------------------------------------------

    public function view_lists()
    {
        ee()->view->cp_page_title = lang('shortlist_list_page');

        ee()->cp->set_breadcrumb($this->eeharbor->moduleURL('index'), lang('shortlist_module_name'));
        $this->_add_morphine();

        $total = ee()->shortlist_list_model->count_all();
        $this->offset = $this->_pagination($total, 'view_lists');

        $this->_get_lists();
        $this->_get_member_data();


        $this->_get_action_uris();
        return  $this->eeharbor->view($this->eeX.'/mcp_lists', $this->cache, true);
    }
    // --------------------------------------------------------------------

    public function settings()
    {
        // --------------------------------------
        // Load some libraries
        // --------------------------------------

        ee()->view->cp_page_title = lang('shortlist_settings_title');
        $this->_add_morphine();

        ee()->load->library('javascript');

        ee()->cp->set_breadcrumb($this->eeharbor->moduleURL('index'), lang('shortlist_module_name'));

        $this->cache['prune_lists_uri'] = $this->eeharbor->moduleURL('prune_lists');

        return  $this->eeharbor->view($this->eeX.'/mcp_settings', $this->cache, true);
    }


    public function prune_lists()
    {
        ee()->shortlist_core_model->prune();

        return ee()->functions->redirect($this->eeharbor->moduleURL('settings'));
    }

    private function _get_clones()
    {
        $clones = array();
        if (isset($this->cache['items']) and !empty($this->cache['items'])) {
            // Get the list id from the items
            $row = current($this->cache['items']);
            $list_id = $row['list_id'];

            $clones = ee()->shortlist_item_model->get_clones($list_id);

            // Cleanup
            foreach ($clones as $key => $clone) {
                if ($clone['member_id'] != '0') {
                    $clones[ $key ]['user_type'] = 'member';

                    // Add this member_id to a temp arrary so we can pull the required member details
                    // in a single query
                    $this->cache['member_data'][ $clone['member_id'] ] = array();
                } else {
                    $clones[ $key ]['user_type'] = 'guest';
                }

                $clones[$key]['list_detail_url'] = $this->eeharbor->moduleURL('view_list', array('list_id'=>$clone['list_id']));

                $clones[$key]['item_detail_url'] = $this->eeharbor->moduleURL('view_item', array('list_id'=>$clone['entry_id']));

                $clones[$key]['added_formatted'] = ee()->localize->human_time($clone['added']);
                $clones[$key]['added_since'] = $this->_time_elapsed_string(ee()->localize->now - $clone['added']);
            }
        }

        $this->cache['clones'] = $clones;
        $this->cache['clones_count'] = count($clones);
    }



    private function _get_lists_for_member($id, $type)
    {
        $lists = ee()->shortlist_list_model->get_lists_for_member($id, $type);

        $total_items = 0;

        // Cleanup the lists
        foreach ($lists as $key => $list) {
            if (isset($list['item_count'])) {
                $total_items += $list['item_count'];
            } else {
                $lists[$key]['item_count'] = 0;
            }

            $lists[$key]['last_change_formatted'] = ee()->localize->human_time($list['last_change']);
            $lists[$key]['last_change_since'] = $this->_time_elapsed_string(ee()->localize->now - $list['last_change']);

            $lists[$key]['list_detail_url'] = $this->eeharbor->moduleURL('view_list', array('list_id'=>$list['list_id']));
            $lists[$key]['list_remove_url'] = $this->eeharbor->moduleURL('act_list_remove', array('ret'=>'view_list', 'list_id'=>$list['list_id']));
        }

        $this->cache['list_count'] = count($lists);
        $this->cache['total_items'] = $total_items;
        $this->cache['lists'] = $lists;
    }

    private function _get_lists_with_entry($entry_id)
    {
        $lists = ee()->shortlist_item_model->get_lists_with_entry($entry_id);

        // Cleanup the lists
        foreach ($lists as $key => $list) {
            if ($list['member_id'] != '0') {
                $lists[ $key ]['user_type'] = 'member';

                // Add this member_id to a temp arrary so we can pull the required member details
                // in a single query
                $this->cache['member_data'][ $list['member_id'] ] = array();
            } else {
                $lists[ $key ]['user_type'] = 'guest';
            }

            $lists[$key]['total_item_count'] = $list['c'];
            $lists[$key]['last_activity_formatted'] = ee()->localize->human_time($list['added']);
            $lists[$key]['last_activity_since'] = $this->_time_elapsed_string(ee()->localize->now - $list['added']);

            $lists[$key]['list_detail_url'] = $this->eeharbor->moduleURL('view_list', array('list_id'=>$list['list_id']));
            $lists[$key]['list_remove_url'] = $this->eeharbor->moduleURL('act_list_remove', array('ret'=>'view_list', 'list_id'=>$list['list_id']));
        }

        $this->cache['list_count'] = count($lists);
        $this->cache['item_lists'] = $lists;
    }

    private function _get_member_data()
    {
        if (! isset($this->cache['member_data']) or empty($this->cache['member_data'])) {
            return;
        }

        $member_ids = array_keys($this->cache['member_data']);

        // Now pull the member details from the db
        $members = ee()->db->select('member_id, group_id, username, screen_name, email')
                        ->where_in('member_id', $member_ids)
                        ->get('members')
                        ->result_array();

        foreach ($members as $member) {
            if (isset($this->cache['member_data'][ $member['member_id'] ])) {
                $this->cache['member_data'][ $member['member_id'] ] = $member;
                $this->cache['member_data'][ $member['member_id'] ]['view_member_uri'] = $this->eeharbor->moduleURL('view_member', array('member_id'=>$member['member_id']));
            }
        }
    }


    private function _get_members()
    {
        // MySQL 5.7.5 workaround. TODO: Come back to this and rewrite these queries.
        ee()->db->query("SET SESSION sql_mode = ''");

        // Also pull all the members for our lists
        $mems = ee()->db->select('member_id, session_id, last_change')
                    ->from('shortlist_list')
                    ->group_by('member_id, session_id')
                    ->where('member_id != "0"')
                    ->or_where('session_id != ""')
                    ->order_by('last_change', 'desc')
                    ->limit($this->limit, $this->offset)
                    ->get()
                    ->result_array();

        $this->cache['members'] = $mems;

        if(isset($this->cache['lists'])) {
            $lists = $this->cache['lists'];
        } else if(isset($this->cache['item_lists'])) {
            $lists = $this->cache['item_lists'];
        }

        // Associate list_ids if we can
        if (isset($lists)) {
            foreach ($mems as $member_key => $member) {
                if ($member['session_id'] == '') {
                    $mems[$member_key]['user_type'] = 'member';
                } else {
                    $mems[$member_key]['user_type'] = 'guest';
                }

                $mems[$member_key]['last_activity_formatted'] = ee()->localize->human_time($member['last_change']);
                $mems[$member_key]['last_activity_since'] = $this->_time_elapsed_string(ee()->localize->now - $member['last_change']);

                $mems[$member_key]['view_member_uri'] = $this->eeharbor->moduleURL('view_member', array('member_id'=>$member['member_id']));
                $mems[$member_key]['lists'] = array();

                foreach ( $lists as $list_key => $list) {
                    if (($member['member_id'] != '0' and $list['member_id'] == $member['member_id'])
                        or ($member['session_id'] != '' and $list['session_id'] == $member['session_id']))
                    {
                        $mems[$member_key]['lists'][] = array('list_id' => $list['list_id'], 'list_title' => $list['list_title'], 'key' => $list_key, 'detail_url' => $this->eeharbor->moduleURL('view_list', array('list_id'=>$list['list_id'])));
                    }
                }
            }
        }

        // Remove any members with no lists
        foreach ($mems as $key => $mem) {
            if (empty($mem['lists'])) {
                unset($mems[$key]);
            }
        }

        $this->cache['members'] = $mems;
    }

    private function _get_items($entry_id = '')
    {
        if ($entry_id == '') {
            ee()->db->limit($this->limit, $this->offset)->order_by('c', 'desc');
            $items = ee()->shortlist_item_model->get_all_items();
        } else {
            $items = ee()->shortlist_item_model->get_one_by_entry_id($entry_id);
        }

        $internal_count = 0;
        $external_count = 0;
        foreach ($items as $key => $item) {
            $type = 'Internal';
            if (isset($item['unique_val'])) {
                $type = 'External';
            }
            $items[ $key ]['type'] = $type;

            if ($type == 'Internal') {
                $internal_count++;

                $items[ $key ]['entry_edit_url'] = $this->eeharbor->cpURL('publish', 'edit', array('entry_id' => $item['entry_id']));
            }
            if ($type == 'External') {
                $external_count++;
            }

            $items[$key]['item_detail_url'] = $this->eeharbor->moduleURL('view_item', array('entry_id'=>$item['entry_id']));
            $items[$key]['remove_item_uri'] = $this->eeharbor->moduleURL('act_item_remove', array('ret'=>'view_item', 'item_id' => $item['item_id']));
            $items[$key]['act_item_remove_all'] = $this->eeharbor->moduleURL('act_item_remove_all', array('entry_id' => $item['entry_id']));

            $items[$key]['added_formatted'] = ee()->localize->human_time($item['added']);
            $items[$key]['added_since'] = $this->_time_elapsed_string(ee()->localize->now - $item['added']);
        }

        $this->cache['item_count'] = count($items);
        $this->cache['internal_count'] = $internal_count;
        $this->cache['external_count'] = $external_count;
        $this->cache['items'] = $items;

        if ($entry_id != '') {
            // This is a single item, we also want to get all the item
            // attributes as passed when added if this is an external item
            $item = current($items);
            if ($item['type'] == 'External') {
                $item_details = ee()->shortlist_channel_model->get_data($item['entry_id']);

                $item['meta'] = $item_details;
            }

            $this->cache['item'] = $item;
        }
    }

    private function _get_items_for_list($list_id = '')
    {
        if ($list_id == '') {
            $items = ee()->shortlist_item_model->get_all_items();
        } else {
            $items = ee()->shortlist_item_model->get_list($list_id, true);
        }

        $internal_count = 0;
        $external_count = 0;

        foreach ($items as $key => $item) {
            $type = 'Internal';
            if (isset($item['unique_val'])) {
                $type = 'External';
            }
            $items[ $key ]['type'] = $type;

            if ($type == 'Internal') {
                $internal_count++;
            }
            if ($type == 'External') {
                $external_count++;
            }

            $items[$key]['item_detail_url'] = $this->eeharbor->moduleURL('view_item', array('entry_id'=>$item['entry_id']));
            $items[$key]['remove_item_uri'] = $this->eeharbor->moduleURL('act_item_remove', array('ret'=>'view_item', 'item_id' => $item['item_id']));

            $items[$key]['added_formatted'] = ee()->localize->human_time($item['added']);
            $items[$key]['added_since'] = $this->_time_elapsed_string(ee()->localize->now - $item['added']);
        }

        $this->cache['item_count'] = count($items);
        $this->cache['internal_count'] = $internal_count;
        $this->cache['external_count'] = $external_count;
        $this->cache['items'] = $items;
    }



    private function _get_lists($list_id = '')
    {
        if ($list_id == '') {
            ee()->db->order_by('last_change', 'desc')
                            ->limit($this->limit, $this->offset);
            $lists = ee()->shortlist_list_model->get_all();
        } else {
            //$lists = ee()->shortlist_item_model->get_list_single( $list_id );
            $lists = array();
            if (empty($lists)) {
                ee()->db->where('list_id', $list_id);
                $lists = ee()->shortlist_list_model->get_all();
            }
        }



        // Cleanup the lists
        foreach ($lists as $key => $list) {
            if ($list['member_id'] != '0') {
                $lists[ $key ]['user_type'] = 'member';

                // Add this member_id to a temp arrary so we can pull the required member details
                // in a single query
                $this->cache['member_data'][ $list['member_id'] ] = array();
            } else {
                $lists[ $key ]['user_type'] = 'guest';
            }

            if (!isset($list['last_change'])) {
                $list['last_change'] = $list['added'];
            }

            $lists[$key]['last_change_since'] = $this->_time_elapsed_string(ee()->localize->now - $list['last_change']);
            $lists[$key]['last_change_formatted'] = ee()->localize->human_time($list['last_change']);

            $lists[$key]['list_detail_url'] = $this->eeharbor->moduleURL('view_list', array('list_id'=>$list['list_id']));
            $lists[$key]['list_remove_url'] = $this->eeharbor->moduleURL('act_list_remove', array('ret'=>'view_list', 'list_id'=>$list['list_id']));
        }

        $this->cache['list_count'] = count($lists);
        $this->cache['lists'] = $lists;

        if ($list_id != '') {
            $this->cache['list'] = current($lists);
        }
    }

    public function save_settings()
    {
        $data = array();

        foreach (ee()->shortlist_example_model->attributes() as $attribute) {
            if (ee()->input->get_post($attribute) != '') {
                $data[ $attribute ] = ee()->input->get_post($attribute);
            }
        }

        ee()->shortlist_example_model->insert($data);

        // ----------------------------------
        //  Redirect to Settings page with Message
        // ----------------------------------
        $this->eeharbor->flashData('message_success', lang('preferences_updated'));

        ee()->functions->redirect($this->eeharbor->moduleURL('settings'));
    }

    private function _add_morphine()
    {
        $theme_folder_url = $this->eeharbor->getAddonThemesDir();

        ee()->cp->add_to_head('<link rel="stylesheet" type="text/css" href="'.$theme_folder_url.'styles/screen.css" />');

        ee()->cp->add_to_foot('<script type="text/javascript" charset="utf-8" src="'.$theme_folder_url.'scripts/compressed.js"></script>');
        ee()->cp->add_to_foot('<script type="text/javascript" charset="utf-8" src="'.$theme_folder_url.'shortlist.js"></script>');

        $this->generateSidebar();
    }

    /**
     * Time String
     *
     * Returns the relative time in a nicer wordy fashion
     *
     * @access	private
     * @return	string
     */

    private function _time_elapsed_string($ptime, $future = false)
    {
        $ago = ee()->lang->line('period_ago');

        if ($ptime < 0) {
            $etime = $ptime * -1;
            $ago = 'left';
        } else {
            $etime = $ptime;
        }

        if ($etime < 1 and $future == false) {
            return ee()->lang->line('period_now');
        }

        $a = array( 12 * 30 * 24 * 60 * 60    =>  'period_year',
                       30 * 24 * 60 * 60        =>  'period_month',
                       24 * 60 * 60             =>  'period_day',
                       60 * 60                  =>  'period_hour',
                       60                       =>  'period_min',
                       1                        =>  'period_sec');

        foreach ($a as $secs => $str) {
            $d = $etime / $secs;

            if ($d >= 1) {
                if ($secs == 60) {
                    $str = 'period_min';
                }

                $r = round($d);

                $str = $str . ($r > 1 ? 's' : '');
                return $r . ' ' . ee()->lang->line($str) . ' ' . $ago;
            }
        }
    }

    private function _get_stats_vc_todo()
    {
        $stats = array();

        $r = ee()->db->query("SELECT COUNT(*) c FROM exp_vc_todo")->row_array();
        $stats['count'] = $r['c'];


        $r = ee()->db->query("SELECT COUNT(DISTINCT member_id) m FROM exp_vc_todo")->row_array();
        $stats['members'] = $r['m'];

        return $stats;
    }

    private function _get_stats_favourites()
    {
        $stats = array();

        $r = ee()->db->query("SELECT COUNT(*) c FROM exp_favorites")->row_array();
        $stats['count'] = $r['c'];


        $r = ee()->db->query("SELECT COUNT(DISTINCT member_id) m FROM exp_favorites")->row_array();
        $stats['members'] = $r['m'];

        return $stats;
    }

    private function _import_from_favorites($data)
    {
        // We're importing.
        // We'll pass over to the core model to the actual work, then redirect as appropriate afterwards here

        // We only really want to load this model when we need to use it. Do it now
        ee()->load->model("shortlist_import_model");

        $state = ee()->shortlist_import_model->import_from_favorites($data);

        if ($state !== false) {
            // It worked.
            ee()->functions->redirect($this->eeharbor->moduleURL('import_complete', array('msg'=>'import_complete')));
        }

        // Something went wrong
        ee()->functions->redirect($this->eeharbor->moduleURL('import_complete', array('msg'=>'error')));
    }

    private function _import_from_vc_todo($data)
    {
        // We're importing.
        // We'll pass over to the core model to the actual work, then redirect as appropriate afterwards here

        // We only really want to load this model when we need to use it. Do it now
        ee()->load->model("shortlist_import_model");

        $state = ee()->shortlist_import_model->import_from_vc_todo($data);

        if ($state !== false) {
            // It worked.
            ee()->functions->redirect($this->eeharbor->moduleURL('import_complete', array('msg'=>'import_complete')));
        }

        // Something went wrong
        ee()->functions->redirect($this->eeharbor->moduleURL('import_complete', array('msg'=>'error')));
    }

    private function _get_action_uris($return = '')
    {
        $this->cache['view_list_uri'] = $this->eeharbor->moduleURL('view_list', array('list_id'=>''));
        $this->cache['member_detail_url'] = $this->eeharbor->moduleURL('view_member')."&";

        $this->cache['remove_list_uri'] = $this->eeharbor->moduleURL('act_list_remove', array('ret' => $return, 'list_id' => ''));
        $this->cache['remove_all_uri'] = $this->eeharbor->moduleURL('act_item_remove_all', array('ret' => $return, 'entry_id' => ''));
        $this->cache['remove_item_uri'] = $this->eeharbor->moduleURL('act_item_remove', array('ret' => $return, 'item_id' => ''));
    }

    public function act_item_remove()
    {
        $item_id = ee()->input->get('item_id');
        if ($item_id == '') {
            $this->eeharbor->flashData('message_error', 'Item was not removed. `item_id` missing.');
            ee()->functions->redirect($this->eeharbor->moduleURL('index'));
        }

        $item = ee()->shortlist_item_model->get_one($item_id, false, false);

        if (empty($item)) {
            $this->eeharbor->flashData('message_error', 'Requested item does not exist.');
            ee()->functions->redirect($this->eeharbor->moduleURL('index'));
        }

        // Remove the Item
        ee()->shortlist_item_model->delete($item_id, 'item_id');
        $this->eeharbor->flashData('message_success', 'Item successfully removed from list.');

        $ret = ee()->input->get('ret');

        if($ret == "view_list")
        {
            ee()->functions->redirect($this->eeharbor->moduleURL($ret, array("list_id" => $item['list_id'])));
        }

        if ($ret == '') {
            $ret = 'index';
        }

        ee()->functions->redirect($this->eeharbor->moduleURL($ret, array("entry_id" => $item['entry_id'])));
    }

    public function act_list_remove()
    {
        $list_id = ee()->input->get('list_id');
        if ($list_id == '') {
            $this->eeharbor->flashData('message_error', 'List was not removed. `list_id` missing.');
            ee()->functions->redirect($this->eeharbor->moduleURL('index'));
        }

        ee()->shortlist_list_model->delete($list_id, 'list_id');
        ee()->shortlist_item_model->delete($list_id, 'list_id');

        $ret = ee()->input->get('ret');
        if ($ret == '') {
            $ret = 'view_members';
        }

        if ($ret == 'view_list') {
            $ret = 'view_lists';
        }

        ee()->functions->redirect($this->eeharbor->moduleURL($ret));
    }

    public function act_item_remove_all()
    {
        $entry_id = ee()->input->get('entry_id');
        if ($entry_id == '') {
            $this->eeharbor->flashData('message_error', 'Item was not removed from every list. `entry_id` missing.');
            ee()->functions->redirect($this->eeharbor->moduleURL('index'));
        }

        ee()->shortlist_item_model->delete($entry_id, 'entry_id');

        ee()->functions->redirect($this->eeharbor->moduleURL('view_items'));
    }

    private function _pagination($total, $method)
    {
        $offset = 0;
        $page = 1;
        $this->cache['prev_link'] = '';
        $this->cache['next_link'] = '';

        $this->cache['current_page'] = $page;
        $this->cache['total_pages'] = $page;
        $this->cache['has_pagination'] = false;

        if ($total > $this->limit) {
            $max_pages = ceil($total / $this->limit);

            if (ee()->input->get('page') != '') {
                $page = ee()->input->get('page');

                $offset = ($page-1) * $this->limit;
            }
            $next_page = $page + 1;
            $prev_page = $page - 1;

            if ($prev_page > 0) {
                $this->cache['prev_link'] = $this->eeharbor->moduleURL($method, array('page'=>$prev_page));
            }
            if ($next_page <= $max_pages) {
                $this->cache['next_link'] = $this->eeharbor->moduleURL($method, array('page'=>$next_page));
            }

            $this->cache['current_page'] = $page;
            $this->cache['total_pages'] = $max_pages;

            $this->cache['has_pagination'] = true;
        }

        return $offset;
    }
}
