<?php

    return array(
        'name'              => 'Shortlist',
        'version'           => '4.0.3',
        'description'       => 'Dynamic user lists on the fly',
        'namespace'         => 'Shortlist',
        'author'            => 'EEHarbor',
        'author_url'        => 'http://eeharbor.com/shortlist',
        'docs_url'          => 'http://eeharbor.com/shortlist/documentation',
        'settings_exist'    => true
    );
