<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}


// include_once config file
include_once PATH_THIRD.'shortlist/config.php';
require_once PATH_THIRD.'shortlist/eeharbor.php';

/**
 * Shortlist Module Class
 *
 * @package         shortlist_ee_addon
 * @author          Tom Jaeger <Tom@EEHarbor.com>
 * @link            http://eeharbor.com/shortlist
 * @copyright       Copyright (c) 2016, Tom Jaeger/EEHarbor
 */

class Shortlist
{
    public $return_data;

    private $tagdata;
    private $data;
    private $cache;
    private $sites;

    private $tag_markers = array('CURRENT_URI', 'CURRENT_URL');
    private $amp = '&';
    private $fake_params = array();
    private $last_segment;

    /**
     * Constructor: sets EE instance
     *
     * @access      public
     * @return      null
     */
    public function __construct()
    {
        $this->eeharbor = new \shortlist\EEHarbor;

        // Define the package path
        ee()->load->add_package_path(PATH_THIRD.'shortlist');
          // Load our helper
        ee()->load->helper('Shortlist_helper');
        ee()->lang->loadfile('shortlist');
        // Load base model
        if (!class_exists('Shortlist_model')) {
            ee()->load->library('Shortlist_model');
        }
        if (!isset(ee()->shortlist_core_model)) {
            Shortlist_model::load_models();
        }

        $this->last_segment = ee()->uri->segment(ee()->uri->total_segments());

        // ee()->load->remove_package_path(PATH_THIRD.'shortlist');

        // Is this user anon?
        // We need a proper session for this to work
        $this->_check_session();

        // Do some quick tag param cleaning for our
        // helper markers
        $this->_clean_tagparams();
    }

    // --------------------------------------------------------------------


    public function item()
    {
        $this->tagdata = ee()->TMPL->tagdata;

        // We require an entry_id or an is_external='yes'
        $entry_id = ee()->TMPL->fetch_param('entry_id');
        $is_external = ee()->TMPL->fetch_param('is_external');
        if ($entry_id == '' and $is_external != 'yes') {
            return $this->no_results();
        }

        $list_orderby = ee()->TMPL->fetch_param('list_orderby');
        $list_sort = ee()->TMPL->fetch_param('list_sort');

        // Also add the lists, and their respective parts
        // Valid cache?
        $lists = ee()->shortlist_list_model->get_lists($list_orderby, $list_sort);

        ee()->shortlist_core_model->flush_db();

        $default_list = array();
        $default_list_id = '';
        if (!empty($lists)) {
            foreach ($lists as $list) {
                if ($list['default_list']) {
                    $default_list = $list;
                    continue;
                }
            }
        }

        if (!empty($default_list)) {
            $default_list_id = $default_list['list_id'];
        }

        // Hand off to item model
        $item = ee()->shortlist_item_model->get_item('', $default_list_id);
        $all = ee()->shortlist_core_model->everything();

        if (empty($item)) {
            // This doesn't exist in ANY lists
            $item['not_in_any_list'] = true;
        } else {
            $item['not_in_any_list'] = false;
        }

        // Add the action urls as appropriate
        $item['add_url'] = $this->shortlist_add();
        $item['remove_url'] = $this->shortlist_remove();
        $item['clear_url'] = $this->shortlist_clear();

        $entry_id = 0;
        if (isset($item['entry_id'])) {
            $entry_id = $item['entry_id'];
        }
        if (isset(ee()->TMPL->tagparams['entry_id'])) {
            $entry_id = ee()->TMPL->tagparams['entry_id'];
        }

        // Get the list_name vars
        $list_names = array();

        foreach ($lists as $key => $list) {
            $lists[$key]['list_add_url'] = $this->shortlist_add(0, false, $list['list_id']);
            $lists[$key]['list_remove_url'] = $this->shortlist_remove(0, false, $list['list_id']);
            $lists[$key]['list_clear_url'] = $this->shortlist_clear($list['list_id']);

            if ($list['list_name'] != '') {
                $list_names[$key][$list['list_name']] = false;
            }

            $lists[$key]['in_list'] = false;

            $this_list = $all['lists'][$list['list_id']];

            // is this item already in this list?
            if (isset($this_list['items']) and !empty($this_list['items']) and $entry_id != 0) {
                foreach ($this_list['items'] as $i) {
                    if ($i['entry_id'] == $entry_id) {
                        $lists[$key]['in_this_list'] = true;
                        $lists[$key]['in_list'] = true;
                        $item['not_in_any_list'] = false;

                        // Also apply

                        continue;
                    }
                }
            }
        }

        $item = $this->_flatten_extra($item);

        $item['lists'] = $lists;
        $this->data = $item;

        $t = ee()->TMPL->parse_variables($this->tagdata, array( $this->data ));
        return $this->_clean_extra($t);
    }

    // --------------------------------------------------------------------

    public function stats()
    {
        $this->tagdata = ee()->TMPL->tagdata;

        $data = ee()->shortlist_core_model->get_stats();


        return ee()->TMPL->parse_variables($this->tagdata, array($data));
    }

    // --------------------------------------------------------------------

    public function lists()
    {
        $this->tagdata = ee()->TMPL->tagdata;

        // Grab any orderby data first
        $orderby = ee()->TMPL->fetch_param('orderby');
        $sort = ee()->TMPL->fetch_param('sort');
        $current_user_only = ee()->shortlist_core_model->check_yes_no('yes', ee()->TMPL->fetch_param('current_user_only'));

        if ($current_user_only) {
            ee()->shortlist_core_model->filter_by_current_user();
        }

        //$sort = 'desc';
        unset(ee()->session->cache['shortlist']['lists']);

        $lists = array();
        // Limiting to just a single list?
        if (ee()->TMPL->fetch_param('list_id') != '' or ee()->TMPL->fetch_param('list_url_title') != '' or ee()->TMPL->fetch_param('list_name') != '') {
            $list = array();
            if (ee()->TMPL->fetch_param('list_id') != '') {
                if (!isset(ee()->session->cache['shortlist']['list'][ee()->TMPL->fetch_param('list_id')])) {
                    ee()->session->cache['shortlist']['list'][ee()->TMPL->fetch_param('list_id')] = ee()->shortlist_list_model->get_list(ee()->TMPL->fetch_param('list_id'));
                }
                $list = ee()->session->cache['shortlist']['list'][ee()->TMPL->fetch_param('list_id')];
            } elseif (ee()->TMPL->fetch_param('list_url_title') != '') {
                if (!isset(ee()->session->cache['shortlist']['list_url_title'][ee()->TMPL->fetch_param('list_url_title')])) {
                    ee()->session->cache['shortlist']['list_url_title'][ee()->TMPL->fetch_param('list_url_title')] = ee()->shortlist_list_model->get_list_by_url(ee()->TMPL->fetch_param('list_url_title'));
                }
                $list = ee()->session->cache['shortlist']['list_url_title'][ee()->TMPL->fetch_param('list_url_title')];
            } elseif (ee()->TMPL->fetch_param('list_name') != '') {
                if (!isset(ee()->session->cache['shortlist']['list_name'][ee()->TMPL->fetch_param('list_name')])) {
                    ee()->session->cache['shortlist']['list_name'][ee()->TMPL->fetch_param('list_name')] = ee()->shortlist_list_model->get_list_by_name(ee()->TMPL->fetch_param('list_name'));
                }
                $list = ee()->session->cache['shortlist']['list_name'][ee()->TMPL->fetch_param('list_name')];
            }

            if (!empty($list)) {
                $lists[0] = $list;
            }
        } elseif (ee()->TMPL->fetch_param('list_url_title_start') != '' or ee()->TMPL->fetch_param('list_url_title_end') != '') {
            // We might have both, pass them regardless
            if (!isset(ee()->session->cache['shortlist']['list_start_end'][ee()->TMPL->fetch_param('list_url_title_start').'-'.ee()->TMPL->fetch_param('list_url_title_end')])) {
                ee()->session->cache['shortlist']['list_start_end'][ee()->TMPL->fetch_param('list_url_title_start').'-'.ee()->TMPL->fetch_param('list_url_title_end')] = ee()->shortlist_list_model->get_lists_by_start_end(ee()->TMPL->fetch_param('list_url_title_start'), ee()->TMPL->fetch_param('list_url_title_end'), $orderby, $sort);
            }
            $list = ee()->session->cache['shortlist']['list_start_end'][ee()->TMPL->fetch_param('list_url_title_start').'-'.ee()->TMPL->fetch_param('list_url_title_end')];
        } else {
            if (!isset(ee()->session->cache['shortlist']['lists-'.$orderby.'-'.$sort])) {
                ee()->session->cache['shortlist']['lists-'.$orderby.'-'.$sort] = ee()->shortlist_list_model->get_lists($orderby, $sort);
            }
            $lists = ee()->session->cache['shortlist']['lists-'.$orderby.'-'.$sort];
        }
        if (empty($lists)) {
            return $this->no_results();
        }

        // Add the total list_count variable
        if ($current_user_only) {
            ee()->shortlist_core_model->filter_by_current_user();
        }

        $list_count = count($lists);
        foreach ($lists as $key => $list) {
            $lists[$key]['list_count'] = $list_count;
        }


        // Do we need the items?
        $marker = 'items';
        $matches = ee()->shortlist_model->match_pair($this->tagdata, $marker);
        if ($matches !== false) {
            $items = ee()->shortlist_item_model->get_all();
        } else {
            $items = array();
        }


        foreach ($lists as $key => $list) {
            $t = $list;
            if (isset($t['is_default']) and $t['is_default'] == true) {
                $t['make_default_url'] = '';
            } else {
                $t['make_default_url'] = $this->shortlist_set_default($list['list_id']);
            }

            $t['remove_list_url'] = $this->shortlist_remove_list($list['list_id']);
            $t['clear_list_url'] = $this->shortlist_clear_list($list['list_id']);

            $i = array();

            foreach ($items as $item_key => $item) {
                if ($item['list_id'] == $list['list_id']) {
                    $i[] = $item;
                    unset($items[ $item_key ]);
                }
            }

            $t['items'] = $i;
            $t['item_count'] = count($t['items']);
            $lists[ $key ] = $t;
        }


        // Now do some magic to replace the sub-loop items,
        // as if the user had used a full shortlist tag
        $return = ee()->TMPL->fetch_param('return');
        if ($return != '') {
            $return = ' return="'.$return.'"';
        }


        $start = '{exp:shortlist:view list_id="{list_id}"'.$return.'}';
        $end = '{/exp:shortlist:view}';
        $replace = $start .' '.$matches[1].' '.$end;

        $this->tagdata = str_replace($matches[0], $replace, $this->tagdata);

        $this->data = $lists;

        return ee()->TMPL->parse_variables($this->tagdata, $lists);
    }

    public function edit_list_form()
    {
        $list_id = $this->last_segment;

        if ($list_id == '') {
            // We only want to view the default list items
            $default_list = ee()->shortlist_list_model->get_default_list();
            if ($default_list !== false) {
                $list_id = $default_list['list_id'];
            }
        }

        $list = ee()->shortlist_list_model->get_create_list(array('list_id' => $list_id));

        // Add in clear, make default and remove urls too
        if ($list['default_list']) {
            $list['make_default_url'] = '';
        } else {
            $list['make_default_url'] = $this->shortlist_set_default($list['list_id']);
        }

        $list['remove_list_url'] = $this->shortlist_remove_list($list['list_id']);
        $list['clear_list_url'] = $this->shortlist_clear_list($list['list_id']);


        $t = $this->_wrap_form('shortlist_list_edit', ee()->TMPL->tagdata, $list);

        return $t;
    }


    public function add_list_form()
    {
        $hidden = ee()->TMPL->tagparams;

        $hidden['dynamic'] = 'yes';

        $t = $this->_wrap_form('create_new_shortlist', ee()->TMPL->tagdata, array(), $hidden);

        return $t;
    }

    public function item_form()
    {
        $hidden = ee()->TMPL->tagparams;

        $t = $this->_wrap_form('act_shortlist_item', ee()->TMPL->tagdata, array(), $hidden);

        return $t;
    }


    public function add_form()
    {
        $hidden = ee()->TMPL->tagparams;

        $hidden['dynamic'] = 'yes';
        $hidden['type'] = 'add';


        $t = $this->_wrap_form('add_to_shortlist', ee()->TMPL->tagdata, array(), $hidden);

        return $t;
    }

    public function remove_form()
    {
        $hidden = ee()->TMPL->tagparams;

        $hidden['dynamic'] = 'yes';
        $hidden['type'] = 'remove';


        $t = $this->_wrap_form('remove_from_shortlist', ee()->TMPL->tagdata, array(), $hidden);

        return $t;
    }

    // --------------------------------------------------------------------

    public function item_in_list()
    {
        $exists = ee()->shortlist_item_model->exists_in_list();

        if ($exists) {
            return 'yes';
        }

        return 'no';
    }

    // --------------------------------------------------------------------
    public function shortlist_remove($item_id = 0, $attr = false, $list_id = '')
    {
        $act_url = $this->_get_action_url('remove_from_shortlist');

        // Take any and all params and wrap them up neatly
        ee()->load->helper('string');

        if ($item_id == 0) {
            $params = $this->fake_params;
            if (isset(ee()->TMPL) && isset(ee()->TMPL->tagparams)) {
                $params = array_merge($params, ee()->TMPL->tagparams);
            }
        } elseif ($attr !== false) {
            $params[ $attr ] = $item_id;
        } else {
            $params['item_id'] = $item_id;
        }

        if (!isset($params['list_id']) and $list_id != '') {
            $params['list_id'] = $list_id;
        }

        $ret = $this->_get_ret_url($params);
        $params = base64_encode(serialize($params));

        $act_url .= $this->amp.'p=' . $params;
        $act_url .= $this->amp.'ret=' . urlencode($ret);

        return $act_url;
    }



    private function _shortlist_toggle($type = 'add', $keys = array())
    {
        if (empty($keys)) {
            return '';
        }


        // Override the params for a moment
        if (isset(ee()->TMPL) && isset(ee()->TMPL->tagparams)) {
            ee()->TMPL->tagparams = $keys;
        } else {
            $this->fake_params = $keys;
        }

        // Make sure we retain our entry_id if we can

        if ($type == 'add') {
            $ret = $this->shortlist_add();
        } else {
            $ret = $this->shortlist_remove();
        }

        // Reset the params
    //  ee()->TMPL->tagparams = $real_params;

        return $ret;
    }


    // --------------------------------------------------------------------

    public function shortlist_remove_list($list_id = '')
    {
        $act_url = $this->_get_action_url('act_shortlist_remove_list');
        $params = array();


        if ($list_id == 'all') {
            $params['all_lists'] = true;
        } elseif ($list_id == '') {
            $params = ee()->TMPL->tagparams;
        } else {
            $params['list_id'] = $list_id;
        }


        // Take any and all params and wrap them up neatly
        ee()->load->helper('string');
        $ret = $this->_get_ret_url($params);
        $params = base64_encode(serialize($params));

        $act_url .= $this->amp.'p=' . $params;
        $act_url .= $this->amp.'ret=' . urlencode($ret);

        return $act_url;
    }



    // --------------------------------------------------------------------

    public function shortlist_clear_list($list_id = '')
    {
        $act_url = $this->_get_action_url('act_shortlist_clear_list');
        $params = array();


        if ($list_id == '') {
            $params = ee()->TMPL->tagparams;
        } else {
            $params['list_id'] = $list_id;
        }


        // Take any and all params and wrap them up neatly
        ee()->load->helper('string');
        $ret = $this->_get_ret_url($params);
        $params = base64_encode(serialize($params));

        $act_url .= $this->amp.'p=' . $params;
        $act_url .= $this->amp.'ret=' . urlencode($ret);

        return $act_url;
    }



    // --------------------------------------------------------------------

    public function shortlist_set_default($list_id = '')
    {
        $act_url = $this->_get_action_url('make_shortlist_default');
        $params = array();


        if ($list_id == '') {
            $params = ee()->TMPL->tagparams;
        } else {
            $params['list_id'] = $list_id;
        }


        // Take any and all params and wrap them up neatly
        ee()->load->helper('string');
        $ret = $this->_get_ret_url($params);
        $params = base64_encode(serialize($params));

        $act_url .= $this->amp.'p=' . $params;
        $act_url .= $this->amp.'ret=' . urlencode($ret);

        return $act_url;
    }

    // --------------------------------------------------------------------

    public function shortlist_add($item_id = 0, $cloned_from = false, $list_id = '')
    {
        $act_url = $this->_get_action_url('add_to_shortlist');

        if ($item_id == 0) {
            $params = $this->fake_params;
            if (isset(ee()->TMPL) && isset(ee()->TMPL->tagparams)) {
                $params = array_merge($params, ee()->TMPL->tagparams);
            }
        } else {
            $params['item_id'] = $item_id;
        }

        $params['cloned_from'] = $cloned_from;

        if (!isset($params['list_id']) and $list_id != '') {
            $params['list_id'] = $list_id;
        }

        // Take any and all params and wrap them up neatly
        ee()->load->helper('string');
        $ret = $this->_get_ret_url($params);
        $params = base64_encode(serialize($params));

        $act_url .= $this->amp.'p=' . $params;
        $act_url .= $this->amp.'ret=' . urlencode($ret);

        return $act_url;
    }

    // --------------------------------------------------------------------

    public function shortlist_add_list()
    {
        $act_url = $this->_get_action_url('create_new_shortlist');

        $params = ee()->TMPL->tagparams;
        $params['marker'] = time();

        // Take any and all params and wrap them up neatly
        ee()->load->helper('string');
        $ret = $this->_get_ret_url($params);
        $params = base64_encode(serialize($params));

        $act_url .= $this->amp.'p=' . $params;
        $act_url .= $this->amp.'ret=' . urlencode($ret);

        return $act_url;
    }

    // --------------------------------------------------------------------

    public function add()
    {
        return $this->shortlist_add();
    }

    // --------------------------------------------------------------------

    public function remove()
    {
        return $this->shortlist_remove();
    }

    // --------------------------------------------------------------------

    public function auto_add()
    {
        return $this->shortlist_add_remove_auto('add');
    }

    // --------------------------------------------------------------------

    public function auto_remove()
    {
        return $this->shortlist_add_remove_auto('remove');
    }

    // --------------------------------------------------------------------

    public function clear()
    {
        return $this->shortlist_clear();
    }

    // --------------------------------------------------------------------

    public function clear_all()
    {
        return $this->shortlist_clear('', true);
    }

    // --------------------------------------------------------------------

    public function auto_clear()
    {
        return $this->shortlist_clear_auto();
    }


    // --------------------------------------------------------------------

    public function auto_clear_all()
    {
        return $this->shortlist_clear_auto(true);
    }


    // --------------------------------------------------------------------

    public function add_list()
    {
        return $this->shortlist_add_list();
    }

    // --------------------------------------------------------------------

    public function auto_add_list()
    {
        return $this->shortlist_add_list_auto();
    }


    // --------------------------------------------------------------------

    public function remove_list()
    {
        return $this->shortlist_remove_list();
    }

    // --------------------------------------------------------------------

    public function clear_list()
    {
        return $this->shortlist_clear_list();
    }


    // --------------------------------------------------------------------

    public function remove_all()
    {
        return $this->shortlist_remove_list('all');
    }

    // --------------------------------------------------------------------

    /**
    * Shortlist Add Remvoe Auto
    *
    * Automatically adds or removes an item
    *
    */

    public function shortlist_add_remove_auto($type = 'add')
    {
        $keys = ee()->TMPL->tagparams;
        if (!is_array($keys)) {
            return;
        }

        $keys = $this->eeharbor->xss_clean($keys);

        // Do we have a flag for logged in users only?
        if (isset($keys['allow_guests'])
            and $keys['allow_guests'] == 'no'
            and ee()->session->userdata('member_id') == '0') {
            return '';
        }


        if ($type == 'add') {
            $state = ee()->shortlist_item_model->add($keys);
        }
        if ($type == 'remove') {
            $state = ee()->shortlist_item_model->remove($keys);
        }

        if (ee()->TMPL->fetch_param('return') != '') {
            ee()->functions->redirect(ee()->TMPL->fetch_param('return'));
        }

        return '';
    }

    // --------------------------------------------------------------------

    /**
    * Shortlist Add List Auto
    *
    * Automatically adds a list (or group of lists) for a user
    *
    */

    public function shortlist_add_list_auto()
    {
        $keys = ee()->TMPL->tagparams;
        if (!is_array($keys)) {
            return;
        }

        $keys = $this->eeharbor->xss_clean($keys);

        // Do we have a flag for logged in users only?
        if (isset($keys['allow_guests'])
            and $keys['allow_guests'] == 'no'
            and ee()->session->userdata('member_id') == '0') {
            return '';
        }


        $make_default = true;
        if (isset($keys['make_default']) and $keys['make_default'] == 'no') {
            $make_default = false;
        }

        $matcher = 'list_title';
        if (isset($keys['list_name']) and $keys['list_name'] != '') {
            $matcher = 'list_name';
        }

        // Pass over to the list model
        $data = ee()->shortlist_list_model->create_unless_exists($keys, $make_default, $matcher);

        if (!is_array($data)) {
            return false;
        }

        if (ee()->TMPL->fetch_param('return') != '') {
            ee()->functions->redirect(ee()->TMPL->fetch_param('return'));
        }

        return '';
    }


    // --------------------------------------------------------------------

    /**
    * Shortlist Clear Auto
    *
    * Clears a users lists right away and silently
    *
    */
    public function shortlist_clear_auto($all_lists = false)
    {
        $params = ee()->TMPL->tagparams;

        if ($all_lists === true) {
            $params['all_lists'] = true;
        } else {
            // Default to the default list
            $l = ee()->shortlist_list_model->get_default_list();
            $params['list_id'] = $l['list_id'];
        }

        if (!is_array($params) or empty($params)) {
            exit();
        }

        // Pass over to the list model
        ee()->shortlist_list_model->clear_list($params);

        if (isset($params['return'])) {
            $return = urldecode($params['return']);
            ee()->functions->redirect($return);
        }

        return;
    }



    // --------------------------------------------------------------------

    public function shortlist_clear($list_id = '', $all_lists = false)
    {
        $act_url = $this->_get_action_url('act_shortlist_clear_list');

        $params = ee()->TMPL->tagparams;

        if (!isset($params['list_id']) and $list_id != '') {
            $params['list_id'] = $list_id;
        } else {
            if ($all_lists === true) {
                $params['all_lists'] = true;
            } else {
                // Default to the default list
                $l = ee()->shortlist_list_model->get_default_list();
                $params['list_id'] = $l['list_id'];
            }
        }

        // Take any and all params and wrap them up neatly
        ee()->load->helper('string');
        $ret = $this->_get_ret_url($params);
        $params = base64_encode(serialize($params));

        $act_url .= $this->amp.'p=' . $params;
        $act_url .= $this->amp.'ret=' . urlencode($ret);

        return $act_url;
    }

    // --------------------------------------------------------------------

    public function clone_url()
    {
        $list_id = ee()->TMPL->fetch_param('list_id');
        return $this->shortlist_clone($list_id);
    }

    // --------------------------------------------------------------------

    public function shortlist_clone($list_id = '')
    {
        if ($list_id == '') {
            return '';
        }

        $act_url = $this->_get_action_url('clone_shortlist');

        $params['list_id'] = $list_id;

        // Take any and all params and wrap them up neatly
        ee()->load->helper('string');
        $ret = $this->_get_ret_url($params);
        $params = base64_encode(serialize($params));

        $act_url .= $this->amp.'p=' . $params;
        $act_url .= $this->amp.'ret=' . urlencode($ret);

        return $act_url;
    }

    public function reorder_uri()
    {
        return $this->_get_action_url('reorder_list');
    }

    // --------------------------------------------------------------------

    public function shortlist_add_remove($type = 'add', $extrakeys = array())
    {
        $keys = $this->_fetch_keys($extrakeys);
        if (!is_array($keys)) {
            exit();
        }

        $keys = $this->eeharbor->xss_clean($keys);
        $list_id = '';

        // Pass over to the list model
        if ($type == 'add') {
            $state = ee()->shortlist_item_model->add($keys);
        } else {
            if (!isset($keys['item_id'])) {
                $list_id = '';
            } else {
                $item = ee()->shortlist_item_model->get_one($keys['item_id']);
                if (!empty($item)) {
                    $list_id = $item['list_id'];
                    $keys['list_id'] = $list_id;
                }
            }

            if (!isset($keys['list_id']) or $keys['list_id'] == '') {
                $keys['list_id'] = ee()->shortlist_item_model->extract_list_id($keys);
            }

            $list_id = $keys['list_id'];
            $state = ee()->shortlist_item_model->remove($keys);
        }

        $this->_break_cache();

        if ($this->is_ajax_request()) {
            // This is an ajax call, don't redirect

            // For the ajax calls we want to return the updated state of the
            // list count, and a new uri to allow the dev to use the action in
            // for a toggle remove/add

            if ($list_id == '') {
                $l = ee()->shortlist_list_model->get_default_list();
                $list_id = $l['list_id'];
            }

            $list = ee()->shortlist_item_model->get_list($list_id);

            $next_type = ($type == 'add' ? 'remove' : 'add');
            $verb = ($type == 'add' ? 'added' : 'removed');

            $toggle_url = $this->_shortlist_toggle($next_type, $keys);

            ee()->output->send_ajax_response(array(
                    'type'          => $type,
                    'list_items'    => $list,
                    'total_items'   => count($list),
                    'toggle_url'    => $toggle_url,
                    'verb'          => $verb,
                    'list_id'       => $list_id,
                    'keys'          => $keys
                ));
        }

        $return = urldecode(ee()->input->get_post('ret'));

        ee()->functions->redirect($return);
        exit();
    }




    public function list_count()
    {
        // Just gets the total number of lists for a user
        ee()->shortlist_core_model->filter_by_current_user();
        $lists = ee()->shortlist_list_model->get_lists();
        $list_count = count($lists);
        return $list_count;
    }


    public function item_count()
    {
        // Just gets the total count for a list for a user

        // Do we have a list_id as a param?
        $list_id = ee()->TMPL->fetch_param('list_id');


        if (!(ee()->TMPL->fetch_param('all_lists') == 'yes') and $list_id == '') {
            // We only want to view the default list items
            $default_list = ee()->shortlist_list_model->get_default_list();
            if ($default_list !== false) {
                $list_id = $default_list['list_id'];
            }
        }

        if ($list_id != '') {
            // Hand off to item model
            $items = ee()->shortlist_item_model->get_list($list_id);
        } else {
            // Hand off to item model
            $items = ee()->shortlist_item_model->get_all();
        }

        $count = count($items);

        return $count;
    }

    // --------------------------------------------------------------------


    // --------------------------------------------------------------------

    public function view($tagdata = '', $tagparams = array())
    {
        if ($tagdata != '') {
            $this->tagdata = $tagdata;
        } else {
            $this->tagdata = ee()->TMPL->tagdata;
        }

        if (!empty($tagparams)) {
            $params = $tagparams;
        } else {
            $params = ee()->TMPL->tagparams;
        }
        $this->_log('Getting the view for Shortlist user');

        // If we're viewing a list by list_id, are they the owner?
        $owner = true;


        // Do we have a list_id as a param? or a list_name?
        $list_id = (isset($params['list_id']) ? $params['list_id'] : '');
        $list_name = (isset($params['list_name']) ? $params['list_name'] : '');
        $list_url_title = (isset($params['list_url_title']) ? $params['list_url_title'] : '');
        $list_url_title_start = (isset($params['list_url_title_start']) ? $params['list_url_title_start'] : '');
        $list_url_title_end = (isset($params['list_url_title_end']) ? $params['list_url_title_end'] : '');



        if (!(isset($params['all_lists']) and $params['all_lists'] == 'yes') and
            ($list_id == '' and $list_name == '' and $list_url_title == '' and $list_url_title_start == '' and $list_url_title_end == '')) {
            // We only want to view the default list items
            $default_list = ee()->shortlist_list_model->get_default_list();
            if ($default_list !== false) {
                $list_id = $default_list['list_id'];
            }
        }

        if ($list_id != '' or $list_name != '' or $list_url_title != '' or $list_url_title_start != '' or $list_url_title_end != '') {
            $list = array();

            if (isset($params['list_owner_id']) and $list_id == '' and $list_name != '') {
                // We actually want to find the lists for a different owner, but we don't have the list_id
                // so we'll run off and get the list_id directly
                $list = ee()->shortlist_list_model->get_list_by_name_for_member($list_name, $params['list_owner_id']);
            } else {
                if ($list_id != '') {
                    // Find the list by id
                    $this->_log('Viewing a specific list - list_id = '.$list_id);
                    $list = ee()->shortlist_list_model->get_list($list_id);
                } elseif ($list_url_title != '') {
                    $this->_log('Viewing a specific list by list_url_title = '.$list_url_title);
                    $list = ee()->shortlist_list_model->get_list_by_url_title($list_url_title);
                } elseif ($list_name != '') {
                    $this->_log('Viewing a specific list by list_name = '.$list_name);
                    $list = ee()->shortlist_list_model->get_list_by_name($list_name);
                } elseif ($list_url_title_start != '' or $list_url_title_end != '') {
                    $this->_log('Viewing a specific list by list_url_title_start/end = '.$list_url_title_start.', '.$list_url_title_end);
                    $lists = ee()->shortlist_list_model->get_lists_by_start_end(ee()->TMPL->fetch_param('list_url_title_start'), ee()->TMPL->fetch_param('list_url_title_end'));
                    $list = current($lists);
                }
            }

            if (!empty($list)) {
                // Hand off to item model
                $items = ee()->shortlist_item_model->get_list($list['list_id'], false, true);
                // Check if they're the owner of this
                $owner = $this->_is_owner($items);
            }
        } else {

            if (isset($params['list_owner_id']))
            {
                $owner_id = (int) $params['list_owner_id'];

                $this->_log('Getting items for user '.$owner_id);
                $items = ee()->shortlist_item_model->get_all_by_member_id($owner_id);
            } else {
                // Hand off to item model
                $this->_log('Getting this user\'s items');
                $items = ee()->shortlist_item_model->get_all();
            }
        }
        if (empty($items)) {
            $this->_log('User shortlist is empty, returning no_results');
            return $this->no_results();
        }

        $entry_ids = array();
        foreach ($items as $key => $item) {
            $remove_url = ($owner ? $this->shortlist_remove($item['item_id']) : $this->shortlist_remove($item['entry_id'], 'entry_id'));
            $add_url = ($owner ? '' : $this->shortlist_add($item['item_id'], $list_id));
            $remove_list_url = ($owner ? '' : $this->shortlist_remove_list($list_id));
            $make_default_url = ($owner ? '' : $this->shortlist_set_default($list_id));
            $clear_list_url = ($owner ? '' : $this->shortlist_clear_list($list_id));
            $clone_url = ($owner ? '' : $this->shortlist_clone($list_id));

            // Is this item in this users' list?
            $in_list = ($owner ? true : $this->_in_list($item['entry_id']));

            $items[$key]['is_owner'] = ($owner ? true : false);
            $items[$key]['remove_url'] = $remove_url;
            $items[$key]['add_url'] = $add_url;
            $items[$key]['in_list'] = $in_list;
            $items[$key]['clone_url'] = $clone_url;
            $items[$key]['remove_list_url'] = $remove_list_url;
            $items[$key]['make_default_url'] = $make_default_url;
            $items[$key]['clear_list_url'] = $clear_list_url;
            $items[$key]['is_external'] = (bool) $items[$key]['unique_val'];
            $items[$key]['is_internal'] = ! (bool) $items[$key]['unique_val'];
            $items[$key]['is_default'] = (bool) $items[$key]['list_default_list'];

            $entry_ids[] = $item['entry_id'];
        }

        if (empty($entry_ids)) {
            $this->_log('User shortlist has no entry_ids, returning no_results');
            return $this->no_results();
        }

        // We can optionally let the user supply their own entry_ids and limits
        // Check these now
        if (isset($params['entry_id'])) {
            // This needs to be a subset
            $passed_ids = explode('|', $params['entry_id']);

            $new_entry_ids = array();
            foreach ($passed_ids as $passed_id) {
                if (in_array($passed_id, $entry_ids)) {
                    $new_entry_ids[] = $passed_id;
                }
            }

            if (empty($new_entry_ids)) {
                $this->_log('User shortlist limited to entries that dont exist in this list');
                return $this->no_results();
            }

            $entry_ids = $new_entry_ids;
        }

        // Cleanup the extra items so we can parse them cleanly
        $items = $this->_flatten_extra_array($items);

        // Now we have the items, we can pass this over to the channel model to do the subclassed work.
        $this->_log('Passing entry_ids to channel, entry_ids = '.print_R($entry_ids, 1));
        $t = $this->_pass_to_channel($entry_ids, $items);

        // Parse out any remaining 'extra:..' markers just to be safe
        $t = $this->_clean_extra($t);

        return $t;
    }
    // --------------------------------------------------------------------


    public function store_track_item()
    {
        $item_id = ee()->TMPL->fetch_param('item_id');

        return '<input type="hidden" name="shortlist_track_item" value="'.$item_id.'"/>';
    }



    // --------------------------------------------------------------------

    private function _flatten_extra_array($items)
    {
        foreach ($items as $key => $item) {
            $items[$key] = $this->_flatten_extra($item);
        }
        return $items;
    }

    private function _flatten_extra($item)
    {
        if (isset($item['extra']) && is_array($item['extra'])) {
            foreach ($item['extra'] as $extraKey => $extraVal) {
                $item['extra:'.$extraKey] = $extraVal;
            }
            unset($item['extra']);
        }

        return $item;
    }



    private function _clean_extra($tagdata)
    {
        $data = array();

        $marker = 'extra:([^'.preg_quote('}').'""]+)';
        $matches = ee()->shortlist_model->match_single($tagdata, $marker);
        $meta_keys = array();
        if ($matches !== false) {
            foreach ($matches[1] as $match) {
                $data['extra:'.$match] = '';
                $meta_keys[] = $match;
            }
        }

        //Nothing to do
        if (empty($data)) {
            return $tagdata;
        }

        // Parse tagdata
        $t = ee()->TMPL->parse_variables(
                $tagdata,
                array($data),
                true
            );
        return $t;
    }

    private function _in_list($entry_id)
    {
        // Do we have a cache?
        if (!isset($this->cache['user_items'])) {
            // Pull fresh from db and add to cache
            // Get this user's items
            $user_items = ee()->shortlist_item_model->get_all();

            $this->cache['user_items'] = $user_items;
        }

        // Loop over the user items to check if this entry_id
        // is already in their list
        $in_list = false;

        foreach ($this->cache['user_items'] as $item) {
            if ($item['entry_id'] == $entry_id) {
                $in_list = true;
                return $in_list;
            }
        }

        return $in_list;
    }

    // --------------------------------------------------------------------

    private function _is_owner($items = array())
    {
        if (empty($items)) {
            return false;
        }

        $row = current($items);

        // If the user is logged in, use that
        if (ee()->session->userdata('member_id') != '0') {
            if ($row['member_id'] == ee()->session->userdata('member_id')) {
                return true;
            }
        } elseif (ee()->session->userdata('session_id') != '0') {
            if ($row['session_id'] == ee()->session->userdata('session_id')) {
                return true;
            }
        } else {
            // No member_id or session_id. Use our own
            if ($row['session_id'] == ee()->shortlist_core_model->get_create_session()) {
                return true;
            }
        }

        return false;
    }
    // --------------------------------------------------------------------


    private function _get_action_url($method_name)
    {
        // Cache the action urls for repeated use
        if (!isset(ee()->session->cache['shortlist']['action_urls'][ $method_name ])) {
            //ee()->db->stop_cache();

            ee()->db->_reset_write();

            $action_id  = ee()->db->where(
                array(
                    'class'     => SHORTLIST_CLASS_NAME,
                    'method'    => $method_name
                )
            )->get('actions')->row('action_id');

            ee()->session->cache['shortlist']['action_urls'][ $method_name ] = ee()->functions->fetch_site_index(0, 0) . '?ACT=' . $action_id;
        }

        return ee()->session->cache['shortlist']['action_urls'][ $method_name ];
    }
    //END get_action_url


    // --------------------------------------------------------------------

    private function _pass_to_channel($entry_ids = array(), $items = array())
    {
        if (class_exists('Channel') === false) {
            require PATH_MOD.'channel/mod.channel.php';
        }

        $this->_log('Passing over to channel');

        $channel = new Channel;

        ee()->TMPL->tagparams['dynamic'] = 'no';
        ee()->TMPL->tagparams['entry_id'] = implode('|', $entry_ids);
        if (ee()->TMPL->fetch_param('orderby') == '') {
            ee()->TMPL->tagparams['fixed_order'] = implode('|', $entry_ids);
        }
        ee()->TMPL->tagparams['show_expired'] = 'yes';
        ee()->TMPL->tagparams['show_future_entries'] = 'yes';
        ee()->TMPL->tagparams['status'] = 'not uZxV9NoUqAfx7RsX2sadfd9rsDgnGKBJPb';
        ee()->TMPL->tagparmas['site_ids'] = ee()->config->item('site_id');
        ee()->TMPL->tagparams['is_shortlist'] = 'yes';

        $this->_setup_sites();

        $channel->is_shortlist = true;
        $channel->shortlist_items = $items;

        // Get the unique val and datablock field_ids here for speed
        // so we don't have to requery them later inside the loop
        $meta = ee()->shortlist_channel_model->get_meta('fields');
        $channel->shortlist_fields = $meta;

        $t = $channel->entries();

        return $t;
    }

    // --------------------------------------------------------------------

    /**
     *  AJAX Request
     *
     *  Tests via headers or GET/POST parameter whether the incoming request is AJAX in nature
     *  Useful when we want to change the output of a method.
     *
     *  @access     public
     *  @return     boolean
     */

    public function is_ajax_request()
    {
        if (ee()->input->server('HTTP_X_REQUESTED_WITH') === 'XMLHttpRequest') {
            return true;
        }


        return false;
    }
    // END is_ajax_request()



    private function _check_session()
    {
        if (ee()->session->userdata('member_id') == '0') {
            if (ee()->session->userdata('session_id') == '0' or ee()->session->userdata('session_id') == false) {
                //  ee()->session->create_new_session(0);
            }
        }
    }



    private function _clean_tagparams()
    {
        if (isset(ee()->TMPL) && isset(ee()->TMPL->tagparams) && !empty(ee()->TMPL->tagparams)) {
            foreach ($this->tag_markers as $marker) {
                if ($key = array_search($marker, ee()->TMPL->tagparams)) {

                    // Replace
                    if ($marker == 'CURRENT_URI') {
                        $marker = ee()->uri->uri_string();
                        if ($marker == '') {
                            $marker = '/';
                        }
                    }


                    if ($marker == 'CURRENT_URL') {
                        $marker = ee()->functions->fetch_current_uri();
                    }

                    ee()->TMPL->tagparams[ $key ] = $marker;
                }
            }
        }
    }


    private function _log($message = '')
    {
        if (SHORTLIST_DEBUG) {
            ee()->TMPL->log_item('Shortlist Debug: '. $message);
        }
    }


    // --------------------------------------------------------------------
    // --------------------------------------------------------------------
    //
    // ACT Endpoints
    //
    // --------------------------------------------------------------------
    // --------------------------------------------------------------------

    /*
    * ACT Endpoint
    *
    * Called from the {exp:shortlist:add} tag
    * Passes off logic to the wrapper function
    */
    public function add_to_shortlist()
    {
        $this->shortlist_add_remove('add');
    }


    /*
    * ACT Endpoint
    *
    * Called from the {exp:shortlist:remove} tag
    * Passes off logic to the wrapper function
    */
    public function remove_from_shortlist()
    {
        $this->shortlist_add_remove('remove');
    }

    /*
    * ACT Endpoint
    *
    * Called from the {exp:shortlist:clone_list} tag
    * and also available within the view tag as {clone_url}
    */
    public function clone_shortlist()
    {
        $keys = $this->_fetch_keys();
        if (!is_array($keys)) {
            exit();
        }

        // Pass over to the list model
        $state = ee()->shortlist_item_model->clone_list($keys);

        if ($this->is_ajax_request()) {
            // This is an ajax call, don't redirect

            // For the ajax calls we want to return the updated state of the
            // list count, and a new uri to allow the dev to use the action in
            // for a toggle remove/add

            $list = ee()->shortlist_item_model->get_all(true);
            $type = 'clone';
            $verb = 'cloned';

            $toggle_url = '';

            ee()->output->send_ajax_response(array(
                    'type'          => $type,
                    'list_items'    => $list,
                    'total_items'   => count($list),
                    'toggle_url'    => $toggle_url,
                    'verb'          => $verb
                ));
        }


        $return = urldecode(ee()->input->get_post('ret'));

        ee()->functions->redirect($return);
        exit();
    }

    /*
    * ACT Endpoint
    *
    * AJAX reordering helper. Accessed via the
    * {exp:shortlist:reorder_uri} tag, and submitted directly
    * to via standard AJAX calls. Expects the lists data to be
    * a serialized array.
    */
    public function reorder_list()
    {
        $items = ee()->input->get_post('item');

        $state = false;

        if (is_array($items)) {
            // Do the reorder
            $state = ee()->shortlist_item_model->reorder($items);
            $this->_break_cache();
        }

        if ($this->is_ajax_request()) {
            // This is an ajax call, don't redirect

            // For the ajax calls we want to return the updated state of the
            // list count, and a new uri to allow the dev to use the action in
            // for a toggle remove/add
            $type = 'reorder';
            $verb = 'reordered';

            ee()->output->send_ajax_response(array(
                    'type'          => $type,
                    'verb'          => $verb,
                    'state'         => $state
                ));

            exit();
        }

        return;
    }





    /*
    * ACT Endpoint
    *
    * Called from the {exp:shortlist:add_list} tag
    * Creates a new clean list for a user
    */
    public function create_new_shortlist()
    {
        $keys = $this->_fetch_keys();
        if (!is_array($keys)) {
            exit();
        }

        $keys = $this->eeharbor->xss_clean($keys);

        $make_default = true;
        if (isset($keys['make_default']) and $keys['make_default'] == 'no') {
            $make_default = false;
        }
        // Pass over to the list model
        $data = ee()->shortlist_list_model->create($keys, $make_default);

        if (!is_array($data)) {
            return false;
        }

        $this->_break_cache();

        if ($this->is_ajax_request()) {
            // This is an ajax call, don't redirect

            // For the ajax calls we want to return the updated state of the
            // list count, and a new uri to allow the dev to use the action in
            // for a toggle remove/add
            $verb = 'created';
            $type = 'list_created';

            ee()->output->send_ajax_response(array(
                    'type'          => $type,
                    'list'          => $data,
                    'verb'          => $verb
                ));
        }

        $return = urldecode(ee()->input->get_post('ret'));

        ee()->functions->redirect($return);
        exit();
    }

    /*
    * ACT Endpoint
    *
    * Called from the {exp:shortlist:list_edit_form} tag
    */
    public function shortlist_list_edit()
    {
        // We're looking to edit some list details
        // Gather the basic details first, authenticate,
        // then hand off to the list model for the heavy lifting
        $list_id = ee()->input->get_post('list_id');

        $list = ee()->shortlist_list_model->get($list_id);

        if (empty($list)) {
            return;
        }

        // Ok, carry on. Looks like a valid case.
        $ret = ee()->shortlist_list_model->edit_list($list);

        $return = urldecode(ee()->input->get_post('ret'));
        ee()->functions->redirect($return);
        exit();
    }

    /*
    * ACT Endpoint
    *
    * Called from the {exp:shortlist:shortlist_set_default} tag
    * and also on edge cases where no default list is found as a fallback
    *
    * Accessible for the user as {make_default_url} within the
    * {exp:shortlist:view} tag pair
    */
    public function make_shortlist_default()
    {
        $keys = $this->_fetch_keys();
        if (!is_array($keys)) {
            exit();
        }
        $keys = $this->eeharbor->xss_clean($keys);

        // Pass over to the list model
        $state = ee()->shortlist_list_model->update_default($keys);


        if ($this->is_ajax_request()) {
            // This is an ajax call, don't redirect

            // For the ajax calls to make default, we just want to return
            // the success/failure state


            $verb = 'defaulted';

            // Also return a generic uri for setting a list as default
            // All a dev need do is append the list_id to this
            $generic_make_default_uri = $this->shortlist_set_default('toggle') . '&list_id=';
            ee()->output->send_ajax_response(array(
                    'type'          => 'make_default',
                    'verb'          => $verb,
                    'toggle'        => $generic_make_default_uri
                ));
            exit();
        }

        $return = urldecode(ee()->input->get_post('ret'));

        ee()->functions->redirect($return);
        exit();
    }


    /*
    * ACT Endpoint
    *
    * Called from the {exp:shortlist:item_form}
    */
    public function act_shortlist_item()
    {
        $item_id = ee()->input->get_post('item_id');

        if ($item_id == '' || $item_id == '{item_id}') {
            $entry_id = ee()->input->get_post('entry_id');
            if ($entry_id != '') {
                // Now check if this is an existing entry, otherwise swap to add mode
                $item = ee()->shortlist_item_model->get_item($entry_id);
                if (isset($item['item_id'])) {
                    $item_id = $item['item_id'];
                } else {
                    $list_id = ee()->input->get_post('list_id', '');
                    $extrakeys = array('dynamic'=>'yes', 'type'=>'add', 'entry_id' => $entry_id, 'list_id' => $list_id);

                    // No item, swap to be add
                    $extra = $this->_pull_extra('extra');
                    if (isset($extra['extra'])) {
                        foreach ($extra['extra'] as $k => $v) {
                            $extrakeys['extra:'.$k] = $v;
                        }
                    }

                    return $this->shortlist_add_remove('add', $extrakeys);
                }
            }
        }
        $return = urldecode(ee()->input->get_post('ret'));
        $extra = $this->_pull_extra($item_id);

        if ($extra === false) {
            if ($this->is_ajax_request()) {
                $verb = 'item_updated';

                ee()->output->send_ajax_response(array(
                        'type'          => 'item',
                        'verb'          => $verb,
                        'item_id'       => $item_id,
                        'state'         => false));
                exit();
            }

            ee()->functions->redirect($return);
            exit();
        }

        // This can only be called by the item owners

        $items = array();
        foreach ($extra as $id => $data) {
            $items[] = ee()->shortlist_item_model->update_extra($id, $data);
        }

        $this->_break_cache();
        if ($this->is_ajax_request()) {
            // This is an ajax call, don't redirect
            $verb = 'items_updated';

            ee()->output->send_ajax_response(array(
                    'type'          => 'items',
                    'verb'          => $verb,
                    'items'          => $items,
                    'state'         => true));
            exit();
        }

        ee()->functions->redirect($return);
        exit();
    }

    /*
    * ACT Endpoint
    *
    * Called from the {remove_list_url} variable on the :lists tag pair
    */
    public function act_shortlist_remove_list()
    {
        $keys = $this->_fetch_keys();
        if (!is_array($keys)) {
            exit();
        }
        $keys = $this->eeharbor->xss_clean($keys);


        if (isset($keys['all_lists']) and $keys['all_lists'] == true) {
            $list_ids = ee()->shortlist_list_model->remove_all_lists();

            $ret = array('type' => 'remove_all_lists',
                        'verb' => 'removed',
                        'list_ids' => $list_ids);
        } else {
            // Pass over to the list model
            $list_id = ee()->shortlist_list_model->remove_list($keys);
            $ret = array('type' => 'remove_list',
                        'verb' => 'removed',
                        'list_id' => $list_id);
        }

        $this->_break_cache();

        if ($this->is_ajax_request()) {
            // This is an ajax call, don't redirect
            $verb = 'removed';

            ee()->output->send_ajax_response($ret);
            exit();
        }

        $return = urldecode(ee()->input->get_post('ret'));

        ee()->functions->redirect($return);
        exit();
    }

    /*
    * ACT Endpoint
    *
    * Called from the {clear_list_url} variable on the :lists tag pair
    */
    public function act_shortlist_clear_list()
    {
        $keys = $this->_fetch_keys();
        if (!is_array($keys)) {
            exit();
        }
        $keys = $this->eeharbor->xss_clean($keys);

        // Pass over to the list model
        $list_id = ee()->shortlist_list_model->clear_list($keys);

        $this->_break_cache();

        if ($this->is_ajax_request()) {
            // This is an ajax call, don't redirect
            $verb = 'cleared';

            ee()->output->send_ajax_response(array(
                    'type'          => 'clear_list',
                    'verb'          => $verb,
                    'list_id'       => $list_id));
            exit();
        }

        $return = urldecode(ee()->input->get_post('ret'));

        ee()->functions->redirect($return);
        exit();
    }




    /*
    * Quick helper function that wraps tagdata
    * in an opening and closing form tags
    * and also adds some hidden fields while it's at it
    */
    private function _wrap_form($act, $tagdata, $data = array(), $hidden_extra = array())
    {
        $form_class = ee()->TMPL->fetch_param('form_class');
        $form_id    = ee()->TMPL->fetch_param('form_id');
        $form_class = $form_class != '' ? ' class="'.$form_class.'"' : '';
        $form_id    = $form_id != '' ? ' id="'.$form_id.'"' : '';
        $form_method = 'POST';

        $ret = $this->_get_ret_url();

        // Get the action_id
        $action_url = $this->_get_action_url($act);

        $hidden = $hidden_extra;
        $hidden['XID'] = '{XID_HASH}';
        $hidden['ret'] = urlencode($ret);

        if (isset($data['list_id'])) {
            $hidden['list_id'] = $data['list_id'];
        }

        // Do we have any special data attributes on the form?
        $dataAttribs = array();
        $param = 'data';
        $matcher = explode(':', $param);
        $matcher = $matcher[0] . ':';

        if (isset(ee()->TMPL) && isset(ee()->TMPL->tagparams) && !empty(ee()->TMPL->tagparams)) {
            foreach (ee()->TMPL->tagparams as $key => $val) {
                if (strpos($key, $matcher) === 0) {
                    $dataAttribs[ str_replace($matcher, '', $key)] = $val;
                }
            }
        }

        if (ee()->TMPL->fetch_param($param) != '') {
            $dataAttribs[$param] = ee()->TMPL->fetch_param($param);
        }
        // Set them up for the form
        $dataset = array();
        foreach ($dataAttribs as $key => $row) {
            $dataset[] = 'data-'.$key.'="'.$row.'"';
        }

        // data attributes?
        $dataparams = $this->_prep_dataparams(); // alternative form for simplicity (data-foo="bar", vs 'data:foo="bar")

        $bare = "<form name='shortlist_form'". $form_class . $form_id ." method='".$form_method."' action='".$action_url."' ".implode($dataset, ' ')." ".$dataparams.">";

        foreach ($hidden as $hidden_key => $hidden_val) {
            $bare .= '<input type="hidden" name="'.$hidden_key.'" value="'.$hidden_val.'"/>';
        }

        $bare .= $tagdata;
        $bare .= "</form>";


        // Parse tagdata
        $t = ee()->TMPL->parse_variables(
                $bare,
                array($data),
                true
            );

        return $t;
    }

    /*
    * Generates the return url for an ACT link
    * based on params and variables
    */
    private function _get_ret_url($params = array())
    {
        $ret = ee()->functions->fetch_current_uri();

        // Directly use the tagparams array as we're calling this dynamically
        // later on for toggle and this bypasses a logic hold
        if (isset(ee()->TMPL) && isset(ee()->TMPL->tagparams['return'])) {
            $ret = ee()->TMPL->tagparams['return'];
            if (isset($params['list_id']) and strpos($ret, '{this_list_id}') > 0) {
                $ret = str_replace('{this_list_id}', $params['list_id'], $ret);
            }
        }


        if (strpos($ret, '{this_list_id}') > 0) {
            $ret = str_replace('{this_list_id}', '', $ret);
        }

        return $ret;
    }


    /**
     * Breaks any caching for the lists if needed
     */
    private function _break_cache()
    {
        $ce_cache_installed = false;

        // Check if Ce_Cache is installed using EE2 and EE3 methods.
        if ($this->eeharbor->module_installed('ce_cache')) {
            if (!class_exists('Ce_cache_break')) {
                include PATH_THIRD . 'ce_cache/libraries/Ce_cache_break.php';
            }

            $cache_break = new Ce_cache_break();
            $items = array();
            $tags = array('shortlist');

            $cache_break->break_cache($items, $tags, false, 1);
        }
    }

    private function _setup_sites()
    {
        if (ee()->config->item('multiple_sites_enabled') != 'y') {
            return;
        } else {
            $sites_query = ee()->db->query("SELECT site_id, site_name FROM exp_sites ORDER BY site_id");

            foreach ($sites_query->result_array() as $row) {
                $this->sites[$row['site_id']] = $row['site_name'];
            }

            ee()->TMPL->site_ids = array_flip($this->sites);
        }
    }


    private function _fetch_keys($extrakeys = array())
    {
        $params = ee()->input->get_post('p');
        $keys = array();

        if ($params != '') {
            ee()->load->helper('string');
            $keys = unserialize(base64_decode($params));
        }
        if (!is_array($keys)) {
            $keys = array();
        }

        $keys = array_merge($keys, $extrakeys);

        if (ee()->input->get_post('dynamic') == 'yes') {
            // Merge in our extra keys
            foreach ($_GET as $key => $val) {
                $keys[$key] = $this->eeharbor->xss_clean($val);
            }
            foreach ($_POST as $key => $val) {
                $keys[$key] = $this->eeharbor->xss_clean($val);
            }
        }

        unset($keys['form_class']);
        unset($keys['form_id']);

        return $keys;
    }


    private function _pull_extra($item_id = '')
    {
        $extra = array();

        foreach ($_REQUEST as $key => $val) {
            if (strpos($key, 'extra:') !== false) {
                $key = str_replace('extra:', '', $key);
                $val = $this->eeharbor->xss_clean($val);

                if (is_array($val)) {
                    foreach ($val as $id => $v) {
                        $extra[$id][$key] = $v;
                    }
                } else {
                    $extra[$item_id][$key] = $val;
                }
            }
        }

        if (empty($extra)) {
            return false;
        }

        return $extra;
    }


    public function no_results()
    {
        if (preg_match(
                "/".LD."if " ."shortlist_no_results" .
                    RD."(.*?)".LD.preg_quote('/', '/')."if".RD."/s",
                ee()->TMPL->tagdata,
                $match
            )
        ) {
            return $match[1];
        } else {
            return ee()->TMPL->no_results();
        }
    }


    private function _prep_dataparams()
    {
        $params = array();
        $tag_params = ee()->TMPL->tagparams;

        if(!empty($tag_params) && is_array($tag_params)) {
            foreach ($tag_params as $key => $val) {
                if (strpos($key, 'data-') === 0) {
                    $params[] = $key . '="'.$val.'"';
                }
            }
        }

        if (empty($params)) {
            return '';
        }

        return implode(' ', $params);
    }
}
