<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

// include_once config file
include_once PATH_THIRD.'shortlist/config.php';
require_once PATH_THIRD.'shortlist/eeharbor.php';

/**
 * Shortlist Update Class
 *
 * @package         shortlist_ee_addon
 * @author          Tom Jaeger <Tom@EEHarbor.com>
 * @link            http://eeharbor.com/shortlist
 * @copyright       Copyright (c) 2016, Tom Jaeger/EEHarbor
 */
class Shortlist_upd
{
    // --------------------------------------------------------------------
    // PROPERTIES
    // --------------------------------------------------------------------

    /**
     * Version number
     *
     * @access      public
     * @var         string
     */
    public $version = SHORTLIST_VERSION;

    private $actions = array(
        'add_to_shortlist',
        'remove_from_shortlist',
        'clone_shortlist',
        'reorder_list',
        'clear_shortlist',
        // New in 2.0
        'create_new_shortlist',
        'make_shortlist_default',
        'shortlist_list_edit',
        'act_shortlist_remove_list',
        'act_shortlist_clear_list',
        // New in 3.0
        'act_shortlist_item'
    );

    // --------------------------------------------------------------------
    // METHODS
    // --------------------------------------------------------------------

    /**
     * Constructor
     *
     * @access      public
     * @return      null
     */
    public function __construct()
    {
        $this->eeharbor = new \shortlist\EEHarbor;

        // Define the package path
        ee()->load->add_package_path(PATH_THIRD.'shortlist');

        // Load our helper
        ee()->load->helper('Shortlist_helper');
        ee()->lang->loadfile('shortlist');

        // Load base model
        if (!class_exists('Shortlist_model')) {
            ee()->load->library('Shortlist_model');
        }
        if (!isset(ee()->shortlist_core_model)) {
            Shortlist_model::load_models();
        }

      //  ee()->load->remove_package_path(PATH_THIRD.'shortlist');
    }

    // --------------------------------------------------------------------

    /**
     * Install the module
     *
     * @access      public
     * @return      bool
     */
    public function install()
    {
        // --------------------------------------
        // Install tables
        // --------------------------------------

        ee()->shortlist_item_model->install();
        ee()->shortlist_list_model->install();
        ee()->shortlist_channel_model->install();

        // --------------------------------------
        // Add row to modules table
        // --------------------------------------

        ee()->db->insert('modules', array(
            'module_name'    => SHORTLIST_CLASS_NAME,
            'module_version' => SHORTLIST_VERSION,
            'has_cp_backend' => 'y'
        ));

        // --------------------------------------
        // Register our actions
        // --------------------------------------

        foreach ($this->actions as $action) {
            ee()->db->insert('actions', array(
                'class'  => SHORTLIST_CLASS_NAME,
                'method' => $action
            ));
        }

        return true;
    }

    // --------------------------------------------------------------------

    /**
     * Uninstall the module
     *
     * @return	bool
     */
    public function uninstall()
    {
        // --------------------------------------
        // get module id
        // --------------------------------------

        $query = ee()->db->select('module_id')
               ->from('modules')
               ->where('module_name', SHORTLIST_CLASS_NAME)
               ->get();

        // --------------------------------------
        // remove references from modules
        // --------------------------------------

        ee()->db->where('module_name', SHORTLIST_CLASS_NAME);
        ee()->db->delete('modules');

        // --------------------------------------
        // remove actions
        // --------------------------------------

        ee()->db->where('class', SHORTLIST_CLASS_NAME);
        ee()->db->delete('actions');

        // --------------------------------------
        // Uninstall tables
        // --------------------------------------

        ee()->shortlist_item_model->uninstall();
        ee()->shortlist_list_model->uninstall();
        ee()->shortlist_channel_model->uninstall();

        return true;
    }

    // --------------------------------------------------------------------

    /**
     * Update the module
     *
     * @return	bool
     */
    public function update($current = '')
    {
        // --------------------------------------
        // Same Version - nothing to do
        // --------------------------------------

        if ($current == '' or version_compare($current, SHORTLIST_VERSION) === 0) {
            return false;
        }

        if (version_compare($current, '1.0.1', '<')) {
            $this->_update_from_101();
        }

        if (version_compare($current, '1.1.0', '<')) {
            $this->_update_from_110();
        }

        if (version_compare($current, '2.0.0.a1', '<')) {
            $this->_update_from_pre_200();
        }

        if (version_compare($current, '2.2.0', '<')) {
            $this->_update_from_220();
        }

        if (version_compare($current, '2.3.3', '<')) {
            $this->_update_from_232();
        }

        if (version_compare($current, '2.3.9', '<')) {
            $this->_update_from_233();
        }

        if (version_compare($current, '3.0.0.a1', '<')) {
            $this->_update_from_pre_300();
        }

        if (version_compare($current, '3.1.2', '<')) {
            $this->_update_from_312();
        }

        // Get the current actions list and compare to the actions list up top.
        $current_actions = ee()->db->where('class', SHORTLIST_CLASS_NAME)->get('actions')->result_array();

        $actions = $this->actions;

        foreach ($current_actions as $act) {
            if (in_array($act['method'], $actions)) {
                foreach ($actions as $key => $action) {
                    if ($action == $act['method']) {
                        unset($actions[ $key ]);
                    }
                }
            }
        }

        // Now just add the ones that aren't there
        foreach ($actions as $action) {
            ee()->db->insert('actions', array(
                'class'  => SHORTLIST_CLASS_NAME,
                'method' => $action
            ));
        }

        // Returning TRUE updates db version number
        return true;
    }

    // --------------------------------------------------------------------

    private function _update_from_101()
    {
        /* There was a misspelling in the config variables
            for the 1.0.0 release, that will have caused the
            channel fields to be named incorrectly, this changes the
            spelling to be correct now */

        // Note the missing 'l' in shortlist_databock
        $sql[] = "UPDATE exp_channel_fields SET field_name = '".SHORTLIST_DATABLOCK_FIELD_NAME."' WHERE field_name = 'shortlist_databock'";

        $sql[] = "UPDATE exp_channel_fields SET field_name = '".SHORTLIST_UNIQUE_FIELD_NAME."' WHERE field_name = 'shortlist_unqiue_val'";

        // Run the queries
        foreach ($sql as $s) {
            ee()->db->query($s);
        }

        return true;
    }

    private function _update_from_110()
    {
        /* There was an unessecary use of the channel_entries_tagdata hook
            which can cause issues
            This clears it out */

        $sql[] = "DELETE FROM exp_extensions WHERE class = 'Shortlist_ext' AND method = 'channel_entries_tagdata'";


        // Run the queries
        foreach ($sql as $s) {
            ee()->db->query($s);
        }

        return true;
    }

    private function _update_from_pre_200()
    {
        ee()->shortlist_list_model->install();

        // Collect together all items that aren't in lists and create lists for them
        $sql = "SELECT i.*
		   			FROM exp_shortlist_item i
						LEFT JOIN exp_shortlist_list l ON l.list_id = i.list_id
					WHERE l.list_id IS NULL
						GROUP BY i.list_id ";
        // No create lists for these orphans
        $s = ee()->db->query($sql);

        foreach ($s->result_array() as $row) {
            // Create list
            $sess = array();
            // Assign this to the current user
            if ($row['member_id'] != '' and $row['member_id'] != '0') {
                $sess['key'] = 'member_id';
                $sess['val'] = $row['member_id'];
            } elseif ($row['session_id'] != '') {
                $sess['key'] = 'session_id';
                $sess['val'] = $row['session_id'];
            }

            ee()->shortlist_list_model->create(array(), true, $row['list_id'], $sess);
        }

        return true;
    }

    private function _update_from_220()
    {
        // Add our private_list colum to the lists table
        $sql = "ALTER TABLE  `exp_shortlist_list` ADD  `private_list` INT( 10 ) UNSIGNED NOT NULL";

        ee()->db->query($sql);

        return true;
    }

    private function _update_from_232()
    {
        // Add our private_list colum to the lists table
        $sql = "ALTER TABLE  `exp_shortlist_list` ADD  `list_description` TEXT";

        ee()->db->query($sql);

        return true;
    }

    private function _update_from_233()
    {
        // Add our private_list colum to the lists table
        $sql = "ALTER TABLE  `exp_shortlist_list` ADD  `list_name` varchar(255) NOT NULL";

        ee()->db->query($sql);

        return true;
    }

    private function _update_from_pre_300()
    {
        $sql = array();
        $sql[] = "ALTER TABLE  `exp_shortlist_item` ADD  `extra` text NOT NULL";

        foreach ($sql as $s) {
            ee()->db->query($s);
        }

        return true;
    }

    private function _update_from_312()
    {
        $sql[] = "ALTER TABLE `exp_shortlist_list` ALTER COLUMN `session_id` SET DEFAULT ''";
        $sql[] = "ALTER TABLE `exp_shortlist_list` ALTER COLUMN `member_id` SET DEFAULT '0'";
        $sql[] = "ALTER TABLE `exp_shortlist_list` ALTER COLUMN `list_id` SET DEFAULT ''";
        $sql[] = "ALTER TABLE `exp_shortlist_list` ALTER COLUMN `list_title` SET DEFAULT ''";
        $sql[] = "ALTER TABLE `exp_shortlist_list` ALTER COLUMN `list_name` SET DEFAULT ''";
        $sql[] = "ALTER TABLE `exp_shortlist_list` ALTER COLUMN `list_url_title` SET DEFAULT ''";
        $sql[] = "ALTER TABLE `exp_shortlist_list` ALTER COLUMN `list_url_title_start` SET DEFAULT ''";
        $sql[] = "ALTER TABLE `exp_shortlist_list` ALTER COLUMN `list_url_title_end` SET DEFAULT ''";
        $sql[] = "ALTER TABLE `exp_shortlist_list` ALTER COLUMN `added_on` SET DEFAULT '0'";
        $sql[] = "ALTER TABLE `exp_shortlist_list` ALTER COLUMN `last_change` SET DEFAULT '0'";
        $sql[] = "ALTER TABLE `exp_shortlist_list` ALTER COLUMN `default_list` SET DEFAULT '0'";
        $sql[] = "ALTER TABLE `exp_shortlist_list` ALTER COLUMN `private_list` SET DEFAULT '0'";

        $sql[] = "ALTER TABLE `exp_shortlist_item` ALTER COLUMN `member_id` SET DEFAULT '0'";
        $sql[] = "ALTER TABLE `exp_shortlist_item` ALTER COLUMN `session_id` SET DEFAULT ''";
        $sql[] = "ALTER TABLE `exp_shortlist_item` ALTER COLUMN `added` SET DEFAULT '0'";
        $sql[] = "ALTER TABLE `exp_shortlist_item` ALTER COLUMN `item_order` SET DEFAULT '0'";
        $sql[] = "ALTER TABLE `exp_shortlist_item` ALTER COLUMN `list_id` SET DEFAULT ''";
        //$sql[] = "ALTER TABLE `exp_shortlist_item` ALTER COLUMN `extra`";

        foreach ($sql as $s) {
            ee()->db->query($s);
        }

        return true;
    }
} // End class

/* End of file upd.Shortlist.php */
