<?php
namespace shortlist;

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * EEHarbor update parent class
 *
 * @package			EEHarbor Update Parent
 * @version			1.3.4
 * @author			Tom Jaeger <Tom@EEHarbor.com>
 * @link			https://eeharbor.com
 * @copyright		Copyright (c) 2016, Tom Jaeger/EEHarbor
 */

class Eeharbor_upd {

	public function __construct()
	{

	}

}
