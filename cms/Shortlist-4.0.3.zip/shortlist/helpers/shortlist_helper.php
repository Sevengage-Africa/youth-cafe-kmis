<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * Shortlist helper class
 *
 * @package         shortlist_ee_addon
 * @author          Tom Jaeger <Tom@EEHarbor.com>
 * @link            http://eeharbor.com/shortlist
 * @copyright       Copyright (c) 2016, Tom Jaeger/EEHarbor
 */

// --------------------------------------------------------------------

/**
 * Object to Array
 *
 * From a multi-dimensional object return a
 * usable multi-dimensional array
 *
 * @param      array
 * @param 	   bool
 * @return     array
 */
if (! function_exists('Shortlist_obj_to_array')) {
    function Shortlist_obj_to_array($obj, $clean = false, $convert = array())
    {
        if (is_object($obj)) {
            $obj = (array) $obj;
        }

        if (is_array($obj)) {
            $new = array();

            foreach ($obj as $key => $val) {
                if ($clean) {
                    $key = str_replace('-', '_', $key);

                    if (isset($convert[ $key ])) {
                        $key = $convert[ $key ];
                    }
                }

                $new[$key] = Shortlist_obj_to_array($val, $clean);
            }
        } else {
            $new = $obj;
        }

        return $new;
    }
}

/**
 * Plural helper
 *
 * @param       int
 * @return      string
 */
if (! function_exists('lang_plural')) {
    function lang_plural($count)
    {
        if ($count == 1)
            return '';

        return 's';
    }
}


/**
 * Plural helper
 *
 * @param       int
 * @return      string
 */
if (! function_exists('lang_switch')) {
    function lang_switch($lang, $count)
    {
        if ($count == 1)
            return lang($lang . '_single');

        return lang($lang . '_plural');
    }
}
/**
 * Debug
 *
 * @param       mixed
 * @param       bool
 * @return      void
 */
if (! function_exists('dumper')) {
    function dumper($var, $exit = true)
    {
        echo '<pre>'.print_r($var, true).'</pre>';

        if ($exit) {
            exit;
        }
    }
}

// --------------------------------------------------------------


/**
 * Associate results
 *
 * Given a DB result set, this will return an (associative) array
 * based on the keys given
 *
 * @param      array
 * @param      string    key of array to use as key
 * @param      bool      sort by key or not
 * @return     array
 */
if (! function_exists('associate_results')) {
    function associate_results($resultset, $key, $sort = false)
    {
        $array = array();

        foreach ($resultset as $row) {
            if (array_key_exists($key, $row) && ! array_key_exists($row[$key], $array)) {
                $array[$row[$key]] = $row;
            }
        }

        if ($sort === true) {
            ksort($array);
        }

        return $array;
    }
}



// --------------------------------------------------------------

/**
 * Is current request an Ajax request or not?
 *
 * @return     bool
 */
if (! function_exists('is_ajax')) {
    function is_ajax()
    {
        return (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest');
    }
}


/* End of file Shortlist_helper.php */
