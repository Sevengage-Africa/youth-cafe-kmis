<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}

// include_once config file
include_once PATH_THIRD.'shortlist/config.php';

/**
 * Shortlist Core Model class
 *
 * @package         shortlist_ee_addon
 * @author          Tom Jaeger <Tom@EEHarbor.com>
 * @link            http://eeharbor.com/shortlist
 * @copyright       Copyright (c) 2016, Tom Jaeger/EEHarbor
 */
class Shortlist_core_model extends Shortlist_model
{

    // 1 week
    protected $expires = 604800;
    protected $cookie_name = 'shortlist_session_id';

    private $everything = array();
    private $reassign_sessions = true;
    private $reassign_merge_lists = false;
    private $cleanup_data = array();
    private static $stats = array();

    /**
     * Constructor
     *
     * @access      public
     * @return      void
     */
    public function __construct()
    {
        $this->reassign_sessions        = SHORTLIST_REASSIGN_GUEST_SESSIONS_ON_LOGIN;
        $this->reassign_merge_lists    = SHORTLIST_REASSIGN_GUEST_SESSIONS_ON_LOGIN_MERGE;

        parent::__construct();
    }

    // --------------------------------------------------------------------

    /**
     * Installs given table
     *
     * @access      public
     * @return      void
     */
    public function install()
    {
        // None
    }


    // --------------------------------------------------------------

    public function get_session()
    {
        $key = '';
        $val = '';

        $alt = array();

        // reassign_sessions
        parent::log('Gettting the user\'s session');
        // If the user is logged in, use that
        if (ee()->session->userdata('member_id') != '0') {
            $key = 'member_id';
            $val = ee()->session->userdata('member_id');
            parent::log('Got session via member_id = '.$val);
        } elseif (ee()->session->userdata('session_id') != '0') {
            $key = 'session_id';
            $val = ee()->session->userdata('session_id');
            parent::log('Got session via session_id = '.$val);
        }


        if (($session_val = $this->get_session_ours()) !== false and $this->reassign_sessions and $key == 'member_id') {
            $alt['key'] = $this->cookie_name;
            $alt['val'] = $session_val;
            parent::log('Found an older shortlist specific session, against a logged in user, reassigning ownership');
        }


        // None found, create our own
        if ($key == '') {
            // No member_id or session_id. Use our own
            // Create or find
            $key = 'session_id';
            $val = $this->get_create_session();
            parent::log('Got session via shortlist session_id = '.$val);
        }

        if (!empty($alt)) {

            // Reassign, and clear the lingering session
            $default_list_id = '';
            if ($this->reassign_merge_lists == true) {
                $default_list_id = '';
                ee()->db->where('default_list', '1');
                $default_list = ee()->shortlist_list_model->get_one($val, 'member_id');

                if (!empty($default_list)) {
                    $default_list_id = $default_list['list_id'];
                } else {
                    $this->reassign_merge_lists = false;
                }
            }

            $cleanup_data = array('member_id' => $val,
                                    'session_id' => $alt['val'],
                                    'reassign_merge_lists' => $this->reassign_merge_lists,
                                    'default_list_id' => $default_list_id );


            ee()->shortlist_list_model->reassign_to_member($val, $alt['val'], $this->reassign_merge_lists);
            ee()->shortlist_item_model->reassign_to_member($val, $alt['val'], $this->reassign_merge_lists, $default_list_id);

            // Clear the session
            if (version_compare(APP_VER, '2.8.0', '<')) {
                ee()->functions->set_cookie($this->cookie_name, false, time() - 36000);
            } else {
                ee()->input->delete_cookie($this->cookie_name);
            }

            ee()->functions->redirect(ee()->functions->fetch_current_uri());
            exit();
        }

        return array( 'key' => $key, 'val' => $val );
    }


    // --------------------------------------------------------------

    public function get_session_ours()
    {
        // Does the session cookie exist?
        if (ee()->input->cookie($this->cookie_name) != false) {
            return ee()->input->cookie($this->cookie_name);
        }

        return false;
    }


    // --------------------------------------------------------------

    public function get_create_session()
    {
        // Does the session cookie exist?
        if (ee()->input->cookie($this->cookie_name) != false) {
            return ee()->input->cookie($this->cookie_name);
        }

        // We need to create the cookie
        $session_id = ee()->functions->random();


        if (version_compare(APP_VER, '2.8.0', '<')) {
            ee()->functions->set_cookie($this->cookie_name, $session_id, $this->expires);
        } else {
            ee()->input->set_cookie($this->cookie_name, $session_id, $this->expires);
        }

        return $session_id;
    }


    // --------------------------------------------------------------

    public function filter_by_current_user()
    {
        if (isset(ee()->session->userdata)) {

            // If the user is logged in, use that
            if (ee()->session->userdata('member_id') != '0') {
                ee()->db->where('member_id', ee()->session->userdata('member_id'));
            } elseif (ee()->session->userdata('session_id') != '0') {
                ee()->db->where('session_id', ee()->session->userdata('session_id'));
            } else {
                // No member_id or session_id. Use our own
                ee()->db->where('session_id', $this->get_create_session());
            }
        }

        return;
    }

    public function prune()
    {
        // Remove any old lists attached to guests.
        $remove_date = ee()->localize->now - $this->expires;

        ee()->shortlist_list_model->prune($remove_date);

        return;
    }

    // --------------------------------------------------------------------

    /**
     * Create URL Title
     *
     */
    public function validate_url_title($url_title = '', $title = '', $list_id = 0)
    {
        $update = false;
        if ($list_id != 0) {
            $update = true;
        }

        $word_separator = ee()->config->item('word_separator');
        ee()->load->helper('url');

        if (! trim($url_title)) {
            $url_title = url_title($title, $word_separator, true);
        }

        // Remove extraneous characters
        if ($update) {
            ee()->db->select('list_url_title');
            $url_query = ee()->db->get_where('shortlist_list', array('list_id' => $list_id));

            if ($url_query->row('list_url_title') != $url_title) {
                $url_title = url_title($url_title, $word_separator);
            }
        } else {
            $url_title = url_title($url_title, $word_separator);
        }


        if ($update) {
            $url_title = $this->_unique_url_title($url_title, $list_id);
        } else {
            $url_title = $this->_unique_url_title($url_title, '');
        }


        return $url_title;
    }

    // --------------------------------------------------------------------

    public function get_stats()
    {
        /*
        <p>There are a total of {total_items} across {total_lists}</p>
        <p>{total_users} total people using lists</p>
        <p>{total_guests} of those are guests, {total_members} are members</p>
        <p>There are {unique_item_count} unqiue items in lists</p>*/

        if (!empty($this->stats)) {
            return $this->stats;
        }

        $data = array(    'total_items' => '0',
                        'total_lists' => '0',
                        'total_users' => '0',
                        'total_guests' => '0',
                        'total_members' => '0',
                        'total_unique_items' => '0');

        // Get the actual stats
        $data = array_merge($data, ee()->shortlist_list_model->get_stats(), ee()->shortlist_item_model->get_stats());

        return $data;
    }

    // --------------------------------------------------------------------

    /**
     * Create URL Title
     *
     */
    public function validate_url_title_end($url_title = '', $start = '', $list_id = false)
    {
        $update = true;
        if ($list_id === false) {
            $update = false;
        }

        $word_separator = ee()->config->item('word_separator');
        ee()->load->helper('url');

        // Remove extraneous characters
        if ($update) {
            ee()->db->select(array('list_url_title_start', 'list_url_title_end'));
            $url_query = ee()->db->get_where('shortlist_list', array('list_id' => $list_id));

            if ($url_query->row('list_url_title_end') != $url_title) {
                $url_title = url_title($url_title, $word_separator);
            }
        } else {
            $url_title = url_title($url_title, $word_separator);
        }



        if ($update) {
            $url_title = $this->_unique_url_title($url_title, $list_id, $start);
        } else {
            $url_title = $this->_unique_url_title($url_title, '', $start);
        }

        return $url_title;
    }


    // --------------------------------------------------------------------

    /**
     * Unique URL Title
     *
     */
    protected function _unique_url_title($url_title, $self_id, $start = '')
    {
        $table = 'shortlist_list';
        $url_title_field = 'list_url_title';
        if ($start != '') {
            $url_title_field = 'list_url_title_end';
        }
        $self_field = 'list_id';

        // Field is limited to 100 characters, so trim url_title before querying
        $url_title = substr($url_title, 0, 100);

        if ($self_id != '') {
            ee()->db->where(array($self_field.' !=' => $self_id));
        }

        if ($start != '') {
            ee()->db->where(array('list_url_title_start' => $start));
        }

        ee()->db->where(array($url_title_field => $url_title));

        $count = ee()->db->count_all_results($table);

        if ($count > 0) {
            // We may need some room to add our numbers- trim url_title to 70 characters
            $url_title = substr($url_title, 0, 70);

            // Check again
            if ($self_id != '') {
                ee()->db->where(array($self_field.' !=' => $self_id));
            }

            if ($start != '') {
                ee()->db->where(array('list_url_title_start' => $start));
            }

            ee()->db->where(array($url_title_field => $url_title));
            $count = ee()->db->count_all_results($table);

            if ($count > 0) {
                if ($self_id != '') {
                    ee()->db->where(array($self_field.' !=' => $self_id));
                }

                if ($start != '') {
                    ee()->db->where(array('list_url_title_start' => $start));
                }

                ee()->db->select("{$url_title_field}, MID({$url_title_field}, ".(strlen($url_title) + 1).") + 1 AS next_suffix", false);
                ee()->db->where("{$url_title_field} REGEXP('".preg_quote(ee()->db->escape_str($url_title))."[0-9]*$')");
                ee()->db->order_by('next_suffix', 'DESC');
                ee()->db->limit(1);
                $query = ee()->db->get($table);

                // Did something go tragically wrong?  Is the appended number going to kick us over the 75 character limit?
                if ($query->num_rows() == 0 or ($query->row('next_suffix') > 99999)) {
                    return false;
                }

                $url_title = $url_title.$query->row('next_suffix');

                // little double check for safety

                if ($self_id != '') {
                    ee()->db->where(array($self_field.' !=' => $self_id));
                }

                if ($start != '') {
                    ee()->db->where(array('list_url_title_start' => $start));
                }

                ee()->db->where(array($url_title_field => $url_title));
                $count = ee()->db->count_all_results($table);

                if ($count > 0) {
                    return false;
                }
            }
        }

        return $url_title;
    }

    public function everything()
    {
        if (!empty($this->everything)) {
            return $this->everything;
        }

        $items = ee()->shortlist_item_model->get_all();
        $lists = ee()->shortlist_list_model->get_lists();

        if (empty($lists)) {
            return array();
        }

        $data['lists'] = array();
        $l = array();
        foreach ($lists as $list) {
            $data['lists'][ $list['list_id'] ] = $list;
            $l[ $list['list_id'] ] = $list;
        }


        $tmp = array();
        foreach ($items as $item) {
            if (!isset($tmp[$item['entry_id']])) {
                $tmp[$item['entry_id']] = array();
            }
            if (!isset($l[ $item['list_id'] ])) {
                continue;
            }

            $data['lists'][$item['list_id']]['items'][] = $item;
            $item['list'] = $l[ $item['list_id'] ];

            $tmp[$item['entry_id']][] = $item;
        }

        $data['items'] = $tmp;


        $this->everything = $data;
        return $this->everything;
    }

    public function check_yes_no($type = 'yes', $value = '')
    {
        if ($value == '') {
            return false;
        }

        $yes_arr = array('yes','y','on','true','t');
        $no_arr = array('no','n','off','false','f');

        if ($type == 'yes') {
            if (in_array($value, $yes_arr)) {
                return true;
            }
            return false;
        } else {
            if (in_array($value, $no_arr)) {
                return true;
            }
            return false;
        }
    }


    /*
    * Flush DB
    *
    * The native flush db functions miss out the order_by details
    * This fixes that and replicates the more complete private _reset_write()
    * call in db_active_record.php
    */
    public function flush_db()
    {
        ee()->db->flush_cache();

        $ar_reset_items = array(
                                'ar_set'        => array(),
                                'ar_from'        => array(),
                                'ar_where'        => array(),
                                'ar_like'        => array(),
                                'ar_orderby'    => array(),
                                'ar_keys'        => array(),
                                'ar_limit'        => false,
                                'ar_order'        => false
                                );

        foreach ($ar_reset_items as $item => $default_value) {
            ee()->db->$item = $default_value;
        }
    }
} // End class

/* End of file Shortlist_core_model.php */
