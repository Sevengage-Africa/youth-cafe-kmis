<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * Shortlist Item Model class
 *
 * @package         shortlist_ee_addon
 * @author          Tom Jaeger <Tom@EEHarbor.com>
 * @link            http://eeharbor.com/shortlist
 * @copyright       Copyright (c) 2016, Tom Jaeger/EEHarbor
 */
class Shortlist_item_model extends Shortlist_model
{
    private $lists = array();

    // --------------------------------------------------------------------
    // METHODS
    // --------------------------------------------------------------------

    /**
     * Constructor
     *
     * @access      public
     * @return      void
     */
    public function __construct()
    {
        // Call parent constructor
        parent::__construct();

        $this->eeharbor = new \shortlist\EEHarbor;

        // Initialize this model
        $this->initialize(
            'shortlist_item',
            'item_id',
            array(
                'site_id'     => 'int(4) unsigned NOT NULL DEFAULT 1',
                'member_id'   => 'int(10) unsigned NOT NULL DEFAULT 0',
                'session_id'  => 'varchar(100) NOT NULL DEFAULT ""',
                'entry_id'    => 'int(10) unsigned',
                'unique_val'  => 'varchar(100)',
                'added'       => 'int(10) unsigned NOT NULL DEFAULT 0',
                'item_order'  => 'int(4) unsigned NOT NULL DEFAULT 0',
                'list_id'     => 'varchar(100) NOT NULL DEFAULT ""',
                'cloned_from' => 'varchar(100)',
                'extra'       => 'text')
        );
    }

    // --------------------------------------------------------------------

    /**
     * Installs given table
     *
     * @access      public
     * @return      void
     */
    public function install()
    {
        // Call parent install
        parent::install();

        // Add indexes to table
        ee()->db->query("ALTER TABLE {$this->table()} ADD INDEX (`site_id`)");
        ee()->db->query("ALTER TABLE {$this->table()} ADD INDEX (`member_id`)");
        ee()->db->query("ALTER TABLE {$this->table()} ADD INDEX (`session_id`)");
    }


    public function get_stats()
    {
        /* 	total_items
            total_unique_items */
        $ret = array();

        $row = ee()->db->select('count(DISTINCT(entry_id)) c')
            ->from('shortlist_item')
            ->get()
            ->row_array();

        $ret['total_unique_items'] = $row['c'];


        $row = ee()->db->select('count(*) c')
            ->from('shortlist_item')
            ->get()
            ->row_array();

        $ret['total_items'] = $row['c'];

        return $ret;
    }

    public function get_list_by_name($list_name = '', $join = false, $get_list = false)
    {
        if ($list_name == '') {
            return array();
        }
        $list_name = strtolower($list_name);

        if ($join == true) {
            ee()->db->select('shortlist_item.*, channel_titles.title')
                ->join('channel_titles', 'shortlist_item.entry_id = channel_titles.entry_id');
        }

        ee()->db->join('shortlist_list l', 'shortlist_item.list_id = l.list_id');
        ee()->shortlist_core_model->filter_by_current_user('l.');

        ee()->db->order_by('item_order', 'asc');
        $items = self::get_some($list_name, 'l.list_name');

        if ($get_list == true) {
            $list = ee()->shortlist_list_model->get_list_by_name($list_name);
            $list = $this->prefix($list, 'list');

            // Merge the items
            foreach ($items as $key => $item) {
                $items[$key] = array_merge($item, $list);
            }
        }

        return $items;
    }


    public function get_list($list_id = '', $join = false, $get_list = false)
    {
        if ($list_id == '') {
            return array();
        }

        if ($join == true) {
            ee()->db->select('shortlist_item.*, channel_titles.title')
                ->join('channel_titles', 'shortlist_item.entry_id = channel_titles.entry_id');
        }

        ee()->db->order_by('item_order', 'asc');

        $items = self::get_some($list_id, 'list_id');

        if ($get_list == true) {
            $list = ee()->shortlist_list_model->get_list($list_id);
            $list = $this->prefix($list, 'list');

            // Merge the items
            foreach ($items as $key => $item) {
                $items[$key] = array_merge($item, $list);
            }
        }

        return $items;
    }

    // --------------------------------------------------------------

    public function get_entry_id_from_item_id($id)
    {
        $attr = 'item_id';
        $ret = parent::get_one($id, $attr);

        if (empty($ret)) {
            return false;
        }

        return $ret['entry_id'];
    }

    public function get_one_by_entry_id($entry_id)
    {
        ee()->db->select('shortlist_item.*, channel_titles.title')
            ->join('channel_titles', 'shortlist_item.entry_id = channel_titles.entry_id');

        return self::get_some($entry_id, 'shortlist_item.entry_id');
    }

    // --------------------------------------------------------------

    public function get_one($id, $attr = false, $user_filter = true)
    {
        if($user_filter) {
            ee()->shortlist_core_model->filter_by_current_user();
        }

        if ($attr == false) {
            $attr = 'item_id';
        }
        $ret = self::get_some($id, $attr);
        if (empty($ret)) {
            return array();
        }

        $row = current($ret);

        return $row;
    }


    // --------------------------------------------------------------

    public function get_some($id, $attr = false)
    {
        $ret_cache = $this->eeharbor->cache('get', 'get_some_'.$id.'_'.$attr, false, false);

        if(!empty($ret_cache)) {
            ee()->db->_reset_select();
            $ret = unserialize($ret_cache);
        } else {
            $ret = parent::get_some($id, $attr);
            $this->eeharbor->cache('set', 'get_some_'.$id.'_'.$attr, serialize($ret), false);
        }

        // Unpack the extra if set
        foreach ($ret as $key => $row) {
            $extra = (isset($row['extra']) ? $row['extra'] : '');
            $ret[$key]['extra'] = $this->_unpack_extra($extra);
        }

        return $ret;
    }

    // --------------------------------------------------------------

    public function get_list_single($list_id)
    {
        ee()->db->select('*, COUNT(*) as c')
            ->order_by('added', 'desc')
            ->where('list_id', $list_id);

        $items = parent::get_all();

        // Check we got something
        $first = current($items);
        if ($first['item_id'] == '') {
            return array();
        }

        return $items;
    }


    // --------------------------------------------------------------

    public function get_all_items()
    {
        // MySQL 5.7.5 workaround. TODO: Come back to this and rewrite these queries.
        ee()->db->query("SET SESSION sql_mode = ''");

        ee()->db->select('shortlist_item.*, channel_titles.title, COUNT(*) as c')
            ->group_by('shortlist_item.entry_id')
            // ->group_by('shortlist_item.item_id')
            ->join('channel_titles', 'shortlist_item.entry_id = channel_titles.entry_id')
            ->order_by('c', 'desc');

        $items = parent::get_all();

        return $items;
    }


    public function get_lists_with_entry($entry_id)
    {
        ee()->db->join('shortlist_list', 'shortlist_item.list_id = shortlist_list.list_id');
        ee()->db->select('*, shortlist_list.*')
            ->where('entry_id', $entry_id);
        $lists = parent::get_all();
        // We also need to count how many total entries each of these lists has

        $list_ids = array();
        foreach ($lists as $key => $list) {
            $list_ids[] = $list['list_id'];
        }

        $list_more = $this->get_some_lists($list_ids);

        $lists = associate_results($lists, 'list_id');

        foreach ($list_more as $more_key => $more) {
            if (isset($lists[$more['list_id']])) {
                $list_more[$more_key]['list_title'] = $lists[$more['list_id']]['list_title'];
                $list_more[$more_key]['list_name'] = $lists[$more['list_id']]['list_name'];
            }
        }

        return $list_more;
    }

    public function get_some_lists($list_ids = array())
    {
        // MySQL 5.7.5 workaround. TODO: Come back to this and rewrite these queries.
        ee()->db->query("SET SESSION sql_mode = ''");

        if (empty($list_ids)) {
            return array();
        }

        ee()->db->select('*, COUNT(*) as c')
            ->group_by('list_id')
            ->order_by('added', 'desc')
            ->where_in('list_id', $list_ids);

        $items = parent::get_all();

        return $items;
    }

    // --------------------------------------------------------------

    public function get_all_lists()
    {
        // MySQL 5.7.5 workaround. TODO: Come back to this and rewrite these queries.
        ee()->db->query("SET SESSION sql_mode = ''");

        ee()->db->select('*, COUNT(*) as c')
            ->group_by('list_id')
            ->order_by('added', 'desc');

        $items = parent::get_all();

        return $items;
    }

    // --------------------------------------------------------------

    public function get_all($join = false)
    {
        if ($join) {
            ee()->db->join('channel_titles', 'shortlist_item.entry_id = channel_titles.entry_id');
        }

        $sess = ee()->shortlist_core_model->get_session();

        return self::get_some($sess['val'], $sess['key']);
    }

    public function get_all_by_member_id($owner_id = null)
    {
        if(!$owner_id)
        {
           return $this->get_all();
        }

        return self::get_some($owner_id, 'member_id');
    }


    // --------------------------------------------------------------


    public function get_clones($list_id = '')
    {
        if ($list_id == '') {
            return array();
        }

        ee()->db->select('shortlist_item.*, channel_titles.title')
            ->join('channel_titles', 'shortlist_item.entry_id = channel_titles.entry_id')
            ->where('cloned_from', $list_id)
            ->order_by('added', 'desc');

        return parent::get_all();
    }

    // --------------------------------------------------------------


    public function get_item($entry_id = '', $list_id = '')
    {
        // If we've been passed an entry_id on the params use it
        if ($entry_id == '') {
            $entry_id = ee()->TMPL->fetch_param('entry_id');
        }

        if ($entry_id != '') {
            $item_cache = $this->eeharbor->cache('get', 'get_item'.$entry_id.'_'.$list_id, false, false);

            if(!empty($item_cache)) {
                ee()->db->_reset_select();
                $item = unserialize($item_cache);
            } else {
                if($list_id != '') ee()->db->where('list_id', $list_id);

                $item = $this->get_one($entry_id, 'entry_id');
                $this->eeharbor->cache('set', 'get_item'.$entry_id.'_'.$list_id, serialize($item), false);
            }

            if (empty($item)) {
                return array();
            }

            $item['in_list'] = true;

            return $item;
        }

        // Otherwise, use the passed params to search for the item
        $is_external = ee()->TMPL->fetch_param('is_external');

        if ($is_external != 'yes') {
            return array();
        }

        // Do we have a marker for unique attribute?
        $unique_attr = ee()->TMPL->fetch_param('unique_attr');
        if ($unique_attr == '') {
            return array();
        }


        $unique_val = ee()->TMPL->fetch_param('attr:' . $unique_attr);
        if ($unique_val == '') {
            // Fallback to the attr w/out attr: prepended just in case
            $unique_val = ee()->TMPL->fetch_param($unique_attr);
            if ($unique_val == '') {
                return array();
            }
        }

        // Now look in the db for this attribute
        if ($list_id != '') {
            ee()->db->where('list_id', $list_id);
        }
        $item = $this->get_one($unique_val, 'unique_val');
        if (empty($item)) {
            return array();
        }

        $item['in_list'] = true;

        return $item;
    }

    public function clone_list($keys = array())
    {
        if (empty($keys) or !isset($keys['list_id'])) {
            return false;
        }

        // Now add each item one-by-one, with a marker of where they came from
        $cloned_from = $keys['list_id'];

        // Create a bare cloned list
        $cloned_keys = $keys;
        unset($cloned_keys['list_id']);
        $cloned_keys['cloned_from'] = $cloned_from;
        $cloned_list = ee()->shortlist_list_model->create($cloned_keys);

        // Get the list items
        $items = $this->get_list($keys['list_id']);

        foreach ($items as $item) {
            $new_keys = array();
            $new_keys['cloned_from'] = $cloned_from;
            $new_keys['entry_id'] = $item['entry_id'];
            $new_keys['list_id'] = $cloned_list['list_id'];

            if ($item['unique_val'] != '') {
                $new_keys['clone_item'] = true;
                $new_keys['unique_val'] = $item['unique_val'];
            }

            foreach ($item['extra'] as $key => $val) {
                $new_keys['extra:'.$key] = $val;
            }

            $this->add($new_keys);
        }

        return;
    }

    // --------------------------------------------------------------

    public function add($keys = array(), $member_id_override = '')
    {
        if (empty($keys)) {
            return false;
        }

        if (ee()->extensions->active_hook('shortlist_add_item_start') === true) {
            $keys = ee()->extensions->call('shortlist_add_item_start', $keys, $member_id_override);
            if (ee()->extensions->end_script === true) {
                return;
            }
        }


        if (isset($keys['clone_item'])) {
            $data['unique_val'] = $keys['unique_val'];
            $entry_id = $keys['entry_id'];
        } elseif (isset($keys['entry_id'])) {
            // This is a local entry
            $entry_id = $keys['entry_id'];
        } elseif (isset($keys['item_id'])) {
            // This is coming from an existing list item
            // Get the entry id from this
            $entry_id = $this->get_entry_id_from_item_id($keys['item_id']);

            if ($entry_id == false) {
                return false;
            }
        } else {
            // This is an external item,
            // we'll have to either create it, or
            // find it's dummy ee entry first
            $entry_id = $this->_find_create_entry($keys);

            // Do we have a marker for unique attribute?
            if (!isset($keys['unique_attr'])) {
                return false;
            }
            $unique_attr = $keys['unique_attr'];
            if ($unique_attr == '') {
                return false;
            }

            if (!isset($keys['attr:' . $unique_attr])) {
                if (!isset($keys[$unique_attr])) {
                    return false;
                } else {
                    $unique_val = $keys[$unique_attr];
                }
            } else {
                $unique_val = $keys['attr:' . $unique_attr];
            }

            $data['unique_val'] = $unique_val;


            if ($entry_id === false) {
                return false;
            }
        }
        ee()->load->helper('string');

        // Just handle adding ee entries for the moment
        $data['site_id'] = ee()->config->item('site_id');
        $data['member_id'] = ee()->session->userdata('member_id');
        $data['session_id'] = ee()->shortlist_core_model->get_create_session();
        $data['entry_id'] = $entry_id;
        $data['added'] = ee()->localize->now;
        $data['item_order'] = 0;
        $data['list_id'] = random_string('alnum', 16);

        // Let the member_id get overridden for imports
        if ($member_id_override != '') {
            $data['member_id'] = $member_id_override;
        }

        $cloned_from = '';
        if (isset($keys['cloned_from']) and $keys['cloned_from'] != '') {
            $cloned_from = $keys['cloned_from'];
        }
        $data['cloned_from'] = $cloned_from;

        // Do we have a list id passed on the request?
        if (isset($keys['list_id']) and $keys['list_id'] != '') {
            $data['list_id'] = $keys['list_id'];
        } elseif (isset($keys['list_url_title']) or isset($keys['list_url_title_start']) or isset($keys['list_url_title_end']) or isset($keys['list_name'])) {
            $list_id = $this->extract_list_id($keys);
            if ($list_id != '') {
                $data['list_id'] = $list_id;
            }
        }

        // Do we have a remove marker?
        if (isset($keys['remove_from_list_id']) or isset($keys['remove_from_list_url_title']) or isset($keys['remove_from_list_url_title_start']) or isset($keys['remove_from_list_url_title_end']) or isset($keys['remove_from_list_name'])) {
            $remove_keys = array();
            $remove_keys['entry_id'] = $entry_id;

            if (isset($keys['remove_from_list_id'])) {
                $remove_keys['list_id'] = $keys['remove_from_list_id'];
            } else {
                $remove_keys['list_id'] = $this->extract_list_id($keys, 'remove_from_');
            }

            $this->remove($remove_keys);
        }

        // Check we've not already got a record for this item
        if ($item_id = $this->_exists_by_id($entry_id, $data['list_id']) !== false) {
            return $item_id;
        }

        // Does this user already have any list items?
        $current = array();
        if ($member_id_override == '') {
            $current = $this->_get_current($data);
        }

        // If this is a clone attempt, and the list_id matches to the current default list,
        // we actually want to create a new list
        if(!(isset($data['cloned_from']) AND isset($current['list_id']) AND $data['cloned_from'] == $current['list_id'])) {
            if (isset($current['list_id'])) $data['list_id'] = $current['list_id'];
        }
        if (isset($current['next_order'])) $data['item_order'] = $current['next_order'];

        // Handle extra values
        $data['extra'] = $this->_extract_and_pack_extra($keys);

        if (ee()->extensions->active_hook('shortlist_item_add_before') === true) {
            ee()->extensions->call('shortlist_item_add_before', $data);
            if (ee()->extensions->end_script === true) {
                return;
            }
        }

        $item_id = self::insert($data);

        if (ee()->extensions->active_hook('shortlist_item_add_after') === true) {
            $data['item_id'] = $item_id; // just to be nice

            ee()->extensions->call('shortlist_item_add_after', $data, $item_id);
            if (ee()->extensions->end_script === true) {
                return;
            }
        }

        return $item_id;
    }

    // --------------------------------------------------------------

    public function clear()
    {
        ee()->shortlist_core_model->filter_by_current_user();
        self::delete();

        return true;
    }

    // --------------------------------------------------------------

    public function remove($keys = array())
    {
        if (empty($keys)) {
            return false;
        }

        if (ee()->extensions->active_hook('shortlist_item_remove_before') === true) {
            ee()->extensions->call('shortlist_item_add_after', $keys);
            if (ee()->extensions->end_script === true) {
                return;
            }
        }

        if (isset($keys['item_id'])) {
            // Directly remove this item
            self::delete($keys['item_id']);

            return true;
        } elseif (isset($keys['entry_id'])) {
            $entry_id = $keys['entry_id'];

            $list_id = '';
            if (isset($keys['list_id'])) {
                $list_id = $keys['list_id'];
            }

            $item_id = $this->_exists_by_id($entry_id, $list_id);

            // Check we've not already got a record for this item
            if ($item_id === false) {
                return true;
            }

            self::delete($item_id);

            return true;
        } elseif (isset($keys['is_external']) and $keys['is_external'] == 'yes') {

            // Do we have a marker for unique attribute?
            if (!isset($keys['unique_attr'])) {
                return false;
            }
            $unique_attr = $keys['unique_attr'];
            if ($unique_attr == '') {
                return false;
            }

            if (!isset($keys['attr:' . $unique_attr])) {
                if (!isset($keys[$unique_attr])) {
                    return false;
                } else {
                    $unique_val = $keys[$unique_attr];
                }
            } else {
                $unique_val = $keys['attr:' . $unique_attr];
            }

            if ($unique_val == '') {
                return false;
            }

            $item_id = $this->_exists_by_unique($unique_val);

            // Check we've not already got a record for this item
            if ($item_id === false) {
                return true;
            }

            self::delete($item_id);

            return true;
        }

        return false;
    }


    // --------------------------------------------------------------

    // --------------------------------------------------------------

    /*
    * Add extra data to items
    *
    * This bypasses the current user restrictions and adds the extra
    * data to any valid item, not just the current user
    * it's used by the store integration to allow marking items as
    * purchased, which occur by users other than the list owner
    */
    public function add_extra_data_to_items($item_ids = array(), $extra_data = array())
    {
        if (empty($item_ids) || empty($extra_data)) {
            return true;
        }

        // Pull the items
        ee()->db->where_in('item_id', $item_ids);
        $items = parent::get_all();

        // Unpack the extra if set
        foreach ($items as $key => $row) {
            $extra = (isset($row['extra']) ? $row['extra'] : '');
            $items[$key]['extra'] = $this->_unpack_extra($extra);
        }

        // Now add our extra data (or overwrite if nessecary)
        foreach ($items as $key => $row) {
            $row_extra = $row['extra'];

            foreach ($extra_data as $extra_key => $extra_val) {
                $row_extra[$extra_key] = $extra_val;
            }

            // Pack up the extra
            $data = array();
            $data['extra'] = base64_encode(serialize($row_extra));
            self::update($row['item_id'], $data);
        }

        return true;
    }


    // --------------------------------------------------------------
    // --------------------------------------------------------------

    private function _get_current($data = array())
    {
        if (empty($data)) {
            return array();
        }


        // Get the current default list, or create a new one if none exists
        $this_list = ee()->shortlist_list_model->get_create_list($data);


        // Look for existing items for this user
        ee()->db->select(array('list_id', 'item_order'));

        // Filter by current user
        ee()->shortlist_core_model->filter_by_current_user();

        ee()->db->where('list_id', $this_list['list_id'])
            ->order_by('item_order', 'desc')
            ->limit(1);


        $result = self::get_all();
        $next_order = 0;
        if (!empty($result)) {
            $row = current($result);
            $next_order = $row['item_order'] + 1;
        }


        return array('list_id' => $this_list['list_id'], 'next_order' => $next_order);
    }

    // --------------------------------------------------------------

    private function _exists_by_unique($unique_val)
    {
        ee()->db->select('item_id');
        ee()->shortlist_core_model->filter_by_current_user();

        ee()->db->where('unique_val', $unique_val);
        $result = self::get_all();

        if (empty($result)) {
            return false;
        }
        $row = current($result);

        return $row['item_id'];
    }


    // --------------------------------------------------------------

    private function _exists_by_id($entry_id, $list_id = '')
    {
        ee()->db->select('item_id');
        ee()->shortlist_core_model->filter_by_current_user();

        if ($list_id != '') {
            ee()->db->where('list_id', $list_id);
        } else {
            ee()->shortlist_list_model->filter_by_default_list();
        }

        ee()->db->where('entry_id', $entry_id);

        $result = self::get_all();

        if (empty($result)) {
            return false;
        }
        $row = current($result);

        return $row['item_id'];
    }

    // --------------------------------------------------------------

    private function _find_create_entry($keys = array())
    {
        if (empty($keys)) {
            return false;
        }

        // Check we're looking for an external item
        if (!(isset($keys['is_external']) and $keys['is_external'] == 'yes')) {
            return false;
        }

        // Do we have a marker for unique attribute?
        if (!isset($keys['unique_attr'])) {
            return false;
        }
        $unique_attr = $keys['unique_attr'];
        if ($unique_attr == '') {
            return false;
        }

        if (!isset($keys['attr:' . $unique_attr])) {
            if (!isset($keys[$unique_attr])) {
                return false;
            } else {
                $unique_val = $keys[$unique_attr];
            }
        } else {
            $unique_val = $keys['attr:' . $unique_attr];
        }


        // Look in the EE dummy channel for this unique val
        $entry_id = ee()->shortlist_channel_model->find_create($unique_val, $keys);

        if ($entry_id === false) {
            return false;
        }


        return $entry_id;
    }


    // --------------------------------------------------------------

    public function reorder($items = array())
    {
        if (empty($items)) {
            return false;
        }

        // Clean the array
        $i = 1;

        foreach ($items as $item) {
            ee()->shortlist_core_model->filter_by_current_user();
            self::update($item, array('item_order' => $i));

            $i++;
        }

        return true;
    }


    // --------------------------------------------------------------

    public function reassign_to_member($member_id, $session_id, $merge = false, $default_list_id = '')
    {
        $data['member_id'] = $member_id;
        $data['session_id'] = '';

        // Get the
        if ($merge == true and $default_list_id != '') {
            $data['list_id'] = $default_list_id;
        }

        ee()->db->where('session_id', $session_id);
        self::update_group($data);

        if ($merge == true and $default_list_id != '') {

            // Check for and remove any duplicates
            $sql = "SELECT a.* FROM exp_shortlist_item a INNER JOIN exp_shortlist_item b ON a.entry_id = b.entry_id WHERE a.member_id = '" . $member_id . "' AND a.list_id = b.list_id AND a.item_id != b.item_id GROUP BY a.item_id";

            $r = ee()->db->query($sql)->result_array();

            $arr = array();
            $found = array();

            if (!empty($r)) {
                // work to do
                foreach ($r as $row) {
                    if (in_array($row['entry_id'], $found)) {
                        $arr[] = $row['item_id'];
                    } else {
                        $found[] = $row['entry_id'];
                    }
                }

                if (!empty($arr)) {
                    ee()->shortlist_item_model->delete($arr, 'item_id');
                }
            }
        }

        return true;
    }

    public function exists_in_list()
    {
        // Get the item id
        $params = ee()->TMPL->tagparams;

        // we need at least
        // 		1. an item id or entry_id
        // 		2. a list id
        $list_id = $this->extract_list_id($params);
        $entry_id = '';

        if ($list_id == '') {
            return false;
        }

        if (isset($params['item_id'])) {
            $entry_id = $this->get_entry_id_from_item_id($params['item_id']);
        } elseif (isset($params['entry_id'])) {
            $entry_id = $params['entry_id'];
        }

        if ($entry_id == '') {
            return false;
        }

        // Get the item from the list
        $item = $this->get_item($entry_id, $list_id);

        if (empty($item)) {
            return false;
        }

        return true;
    }


    public function extract_list_id($keys = array(), $prefix = '')
    {
        // We're acting on a single list, but passed via a friendly string.
        // We'll need to get the list_id for this
        if (empty($this->lists)) {
            $this->lists = ee()->shortlist_list_model->get_lists();
        }

        if (isset($keys[$prefix . 'list_url_title'])) {
            foreach ($this->lists as $list) {
                if ($list['list_url_title'] == $keys[$prefix . 'list_url_title']) {
                    return $list['list_id'];
                }
            }
        } elseif (isset($keys[$prefix . 'list_name'])) {
            foreach ($this->lists as $list) {
                if ($list['list_name'] == $keys[$prefix . 'list_name']) {
                    return $list['list_id'];
                }
            }
        } elseif (isset($keys[$prefix . 'list_id'])) {
            foreach ($this->lists as $list) {
                if ($list['list_id'] == $keys[$prefix . 'list_id']) {
                    return $list['list_id'];
                }
            }
        } else {
            // we need to handle all three cases,
            // just the _start and _end seperately, but also together
            $start = (isset($keys[$prefix . 'list_url_title_start']) ? $keys[$prefix . 'list_url_title_start'] : '');
            $end = (isset($keys[$prefix . 'list_url_title_end']) ? $keys[$prefix . 'list_url_title_end'] : '');


            foreach ($this->lists as $list) {
                $start_id = '';
                $end_id = '';
                if ($start != '' and $list['list_url_title_start'] == $start) {
                    $start_id = $list['list_id'];

                    if ($end == '') {
                        return $start_id;
                    }
                }

                if ($end != '' and $list['list_url_title_end'] == $end) {
                    $end_id = $list['list_id'];

                    if ($start == '') {
                        return $end_id;
                    }
                }

                if ($start_id == $end_id and $start_id != '') {
                    return $start_id;
                }
            }
        }

        return '';
    }


    public function update_extra($item_id, $extra = array())
    {
        $item = self::get_one($item_id);
        if (empty($item)) {
            return false;
        }

        // Pack up the extra
        $data['extra'] = base64_encode(serialize($extra));
        self::update($item_id, $data);

        $item['extra'] = $extra;

        return $item;
    }


    private function _unpack_extra($extra = '')
    {
        $ret = array();
        if ($extra == '') {
            return $ret;
        }

        $ret = unserialize(base64_decode($extra));

        return $ret;
    }


    private function _extract_and_pack_extra($keys = array())
    {
        $ret = '';
        if (empty($keys)) {
            return $ret;
        }

        // Pull out the extra keys from the passed keys
        $temp = array();
        foreach ($keys as $key => $val) {
            if (strpos($key, 'extra:') !== false) {
                $key = str_replace('extra:', '', $key);
                $val = $this->eeharbor->xss_clean($val);
                $temp[$key] = $val;
            }
        }

        if (empty($temp)) {
            return '';
        }

        $ret = base64_encode(serialize($temp));

        return $ret;
    }


    public function count_all()
    {
        // MySQL 5.7.5 workaround. TODO: Come back to this and rewrite these queries.
        ee()->db->query("SET SESSION sql_mode = ''");

        ee()->db->group_by('entry_id');

        ee()->db->select('COUNT(*) c');

        $c = count(self::get_all());

        return $c;
    }
} // End class

/* End of file Shortlist_project_model.php */
