<div id="shortlist_container" class="mor">

	<div class="tg">
		<h2>Shortlist Overview</h2>
	</div>

	<div class="tg third first">
		<h3><?=lang('items')?> <span class="smallAll"><a href="<?=$items_uri?>">View All</a></h3>

		<table class="data">
			<thead>
				<tr style="background-color :transparent">
					<th><?=lang('shortlist_title')?></th>
					<th><?=lang('count')?></th>
				</tr>
			</head>
			<tbody>
				<?php foreach( $items as $item ) : ?>
				<tr>
					<td><a href="<?=$item['item_detail_url']?>"><?=$item['title']?></a></td>
					<td><?=$item['c']?></td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<div class="tg third">
		<h3><?=lang('lists')?> <span class="smallAll"><a href="<?=$lists_uri?>">View All</a></span></h3>

		<table class="data">
			<thead>
				<tr style="background-color :transparent">
					<th><?=lang('list_title')?></th>
					<th><?=lang('shortlist_user_or_guest')?></th>
					<th><?=lang('shortlist_last_active')?></th>
				</tr>
			</head>
			<tbody>

				<?php foreach( $lists as $list ) : ?>
				<tr>
					<td><a href="<?=$list['list_detail_url']?>">
						<?=$list['list_title']?>
						</a>
					</td>
					<td>
						<?php if( $list['user_type'] == 'guest' ) : ?>[ <a href="<?=$member_detail_url.'session_id='.$list['session_id']?>"><?=lang('shortlist_guest')?></a> ]
						<?php else : ?><a href="<?=$member_detail_url.'member_id='.$list['member_id']?>">
							<?php if(isset($member_data[ $list['member_id'] ]['screen_name'])) : ?>
								<?=$member_data[ $list['member_id'] ]['screen_name']?>
							<?php else : ?>
								User <?=$list['member_id']?>
							<?php endif; ?>
						</a>
						<?php endif;?>
					</td>
					<td><?=$list['last_change_since']?></td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<div class="tg third last">
		<h3>Members <span class="smallAll"><a href="<?=$members_uri?>">View All</a></span></h3>

			<table class="data">
			<thead>
				<tr style="background-color :transparent">
					<th><?=lang('shortlist_member')?></th>
					<th><?=lang('shortlist_member_lists')?></th>
					<th><?=lang('shortlist_last_active')?></th>
				</tr>
			</head>
			<tbody>

				<?php foreach( $members as $member ) : ?>
				<tr>
					<td>
						<?php if($member['user_type'] == 'guest') : ?>[ <a href="<?=$member_detail_url.'session_id='.$member['session_id']?>"><?=lang('shortlist_guest')?></a> ]
						<?php else : ?>
							<a href="<?=$member_detail_url.'member_id='.$member['member_id']?>">
								<?php if(isset($member_data[ $member['member_id'] ]['screen_name'])) : ?>
									<?=$member_data[ $member['member_id'] ]['screen_name']?>
								<?php else : ?>
									Member <?=$member['member_id']?>
								<?php endif; ?>
							</a>
						<?php endif;?>
					</td>
					<td>
						<?php foreach($member['lists'] as $member_list) : ?>
							<a href="<?=$member_list['detail_url']?>"><?=$member_list['list_title']?></a>
						<?php endforeach; ?>
					</td>
					<td><?=$member['last_activity_since']?></td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>