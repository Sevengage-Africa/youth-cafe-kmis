<div id="shortlist_container" class="mor">
	<div class="tg" style="">
		<h2>Import Complete</h2>
		<div class="alert">
			The import completed successfully.
		</div>
	</div>
</div>