<div id="shortlist_container" class="mor">


	<div class="tg">
		<h3><?=lang_switch('shortlist_list_item', $item_count)?> : <?=$item_count?> <?=lang_switch('shortlist_item', $item_count )?></h3>


		<table class="data">
			<thead>
				<tr style="background-color :transparent">
					<th><?=lang('shortlist_title')?></th>
					<th><?=lang('count')?></th>
				</tr>
			</head>
			<tbody>

				<?php foreach( $items as $item ) : ?>
				<tr>
					<td><a href="<?=$item['item_detail_url']?>"><?=$item['title']?></a></td>
					<td><?=$item['c']?></td>
				</tr>
				<?php endforeach; ?>

			</tbody>

		</table>
	</div>


	<?php if($has_pagination) : ?>
		<ul class="pagination">

			<li>Page <?=$current_page?> of <?=$total_pages?></li>
			<li>
				<?php if( $prev_link ) : ?>
					<a href="<?=$prev_link?>" title="Previous page">Previous</a>
				<?php else : ?>
					<b>Previous</b>
				<?php endif; ?>
			</li>
			<li>
				<?php if( $next_link ) : ?>
					<a href="<?=$next_link?>" title="Next page">Next</a>
				<?php else : ?>
					<b>Next</b>
				<?php endif; ?>
			</li>
		</ul>
	<?php endif; ?>

</thead>