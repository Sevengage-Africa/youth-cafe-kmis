<div id="shortlist_container" class="mor">



	<div class="tg" style="width : 49%; float :left; margin-right : 1%">
		<h2><?=lang('shortlist_details_about_this_member')?></h2>

		<table class="data">
			<tbody>

				<?php if($user_type == 'session_id'): ?>
					<tr>
						<td style="text-align:right; width: 40%;"><?=lang('shortlist_guest')?></td>
						<td><p><strong><?=$user_id?></strong></p>
							<p><?=lang('shortlist_guest_detail')?></p></td>
					</tr>

				<?php else : ?>
					<tr>
						<td style="text-align:right; width: 40%;"><?=lang('screen_name')?></td>
						<td><strong><?=$member_data[$user_id]['screen_name']?></strong></td>
					</tr>


					<tr>
						<td style="text-align:right; width: 40%;"><?=lang('Email')?></td>
						<td><strong><?=$member_data[$user_id]['email']?></strong></td>
					</tr>

					<tr>
						<td style="text-align:right; width: 40%;"><?=lang('member_id')?></td>
						<td><strong><?=$member_data[$user_id]['member_id']?></strong></td>
					</tr>

					<tr>
						<td style="text-align:right; width: 40%;"><?=lang('member_group')?></td>
						<td><strong><?=$member_data[$user_id]['group_id']?></strong></td>
					</tr>

				<?php endif; ?>


			</tbody>

		</table>

	</div>


	<div class="tg" style="width : 49%; float :left">
		<h2><?=lang('shortlist_user_lists_count')?> <?=$list_count?> <?=lang_switch('shortlist_list',$list_count)?></h2>

		<table class="data">
			<thead>
				<tr style="background-color :transparent">
					<th><?=lang('list_title')?></th>
					<th><?=lang('item_count')?></th>
					<th><?=lang('shortlist_last_active')?></th>
					<th></th>
				</tr>
			</head>
			<tbody>

				<?php foreach( $lists as $list ) : ?>
				<tr>
					<td>
						<a href="<?=$list['list_detail_url']?>"><?=$list['list_title']?></a>
					</td>
					<td><?=$list['item_count']?></td>
					<td><?=$list['last_change_since']?></td>
					<td><a href="<?=$remove_list_uri.$list['list_id']?>"><?=lang('shortlist_remove_this_list')?></a></td>
				</tr>
				<?php endforeach; ?>

			</tbody>

		</table>

	</div>







</div>