<div id="shortlist_container" class="mor">
	<div class="tg" style="">
		<h2><?=lang('shortlist_settings_title')?></h2>

		<table class="data">
			<thead>
				<tr style="background-color:transparent">
					<th style="width:40%; text-align:left;">Options</th>
					<th style="width:60%; text-align:left;"></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>
						<p><strong>List Pruning</strong><br/>
						Prune lists and items that have been untouhed for a long period.</p>
						<p>This will remove all guest lists older than 7 days</p>
					</td>
					<td>
						<a href="<?=$prune_lists_uri?>" class="btn btn2">Prune Old Lists</a>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>