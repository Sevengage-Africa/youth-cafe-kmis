<div id="shortlist_container" class="mor">


	<div class="tg">
		<h3><?=lang_switch('shortlist_user_list', $list_count)?> : <?=$list_count?> <?=lang_switch('shortlist_list', $list_count )?></h3>


		<table class="data">
			<thead>
				<tr style="background-color :transparent">
					<th><?=lang('list_title')?></th>
					<th><?=lang('shortlist_user_or_guest')?></th>
					<th><?=lang('shortlist_last_active')?></th>
				</tr>
			</head>
			<tbody>

				<?php foreach( $lists as $list ) : ?>
				<tr>
					<td><a href="<?=$list['list_detail_url']?>">
						<?=$list['list_title']?>
						</a>
					</td>
					<td>
						<?php if( $list['user_type'] == 'guest' ) : ?>[ <?=lang('shortlist_guest')?> ]
						<?php else : ?><?=$member_data[ $list['member_id'] ]['screen_name']?><?php endif;?>
					</td>
					<td><?=$list['last_change_since']?></td>
				</tr>
				<?php endforeach; ?>

			</tbody>

		</table>
	</div>


	<?php if($has_pagination) : ?>
		<ul class="pagination">

			<li>Page <?=$current_page?> of <?=$total_pages?></li>
			<li>
				<?php if( $prev_link ) : ?>
					<a href="<?=$prev_link?>" title="Previous page">Previous</a>
				<?php else : ?>
					<b>Previous</b>
				<?php endif; ?>
			</li>
			<li>
				<?php if( $next_link ) : ?>
					<a href="<?=$next_link?>" title="Next page">Next</a>
				<?php else : ?>
					<b>Next</b>
				<?php endif; ?>
			</li>
		</ul>
	<?php endif; ?>

</thead>