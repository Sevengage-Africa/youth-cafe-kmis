<div id="shortlist_container" class="box">

	<div class="tbl-ctrls">
		<h1>Shortlist Overview</h1>

		<h3><?=lang('items')?></h3>
		<div class="tbl-wrap">
<?php if (count($items) == 0) {
    ?>
				<table cellspacing="0" class="empty no-results">
					<tbody>
						<tr>
							<td>No items found</td>
						</tr>
					</tbody>
				</table>
<?php
} else {
    ?>
			<table class="">
				<thead>
					<tr>
						<th><?=lang('shortlist_title')?></th>
						<th><?=lang('count')?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($items as $item) : ?>
					<tr>
						<td><a href="<?=$item['item_detail_url']?>"><?=$item['title']?></a></td>
						<td><?=$item['c']?></td>
					</tr>
					<?php endforeach; ?>
				</tbody>
				<tr class="tbl-action">
					<td colspan="3"><a class="btn action submit" href="<?=$items_uri?>">View All</a></td>
				</tr>
			</table>
<?php
} ?>
		</div>
		<br />

		<h3><?=lang('lists')?></h3>
		<div class="tbl-wrap">
<?php if (count($lists) == 0) {
    ?>
			<table cellspacing="0" class="empty no-results">
				<tbody>
					<tr>
						<td>No lists found</td>
					</tr>
				</tbody>
			</table>
<?php
} else {
    ?>
			<table class="">
				<thead>
					<tr>
						<th><?=lang('list_title')?></th>
						<th><?=lang('shortlist_user_or_guest')?></th>
						<th><?=lang('shortlist_last_active')?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ($lists as $list) : ?>
					<tr>
						<td><a href="<?=$list['list_detail_url']?>">
							<?=$list['list_title']?>
							</a>
						</td>
						<td>
							<?php if ($list['user_type'] == 'guest') : ?>[ <a href="<?=$member_detail_url.'session_id='.$list['session_id']?>"><?=lang('shortlist_guest')?></a> ]
							<?php else : ?><a href="<?=$member_data[$list['member_id']]['view_member_uri']?>">
								<?php if (isset($member_data[ $list['member_id'] ]['screen_name'])) : ?>
									<?=$member_data[ $list['member_id'] ]['screen_name']?>
								<?php else : ?>
									User <?=$list['member_id']?>
								<?php endif; ?>
							</a>
							<?php endif; ?>
						</td>
						<td><?=$list['last_change_since']?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
				<tr class="tbl-action">
					<td colspan="3"><a class="btn action submit" href="<?=$lists_uri?>">View All</a></td>
				</tr>
			</table>
<?php
} ?>
		</div>
		<br />

		<h3>Members</h3>
		<div class="tbl-wrap">
<?php if (count($members) == 0) {
    ?>
			<table cellspacing="0" class="empty no-results">
				<tbody>
					<tr>
						<td>No members found</td>
					</tr>
				</tbody>
			</table>
<?php
} else {
    ?>
			<table class="">
				<thead>
					<tr>
						<th><?=lang('shortlist_member')?></th>
						<th><?=lang('shortlist_member_lists')?></th>
						<th><?=lang('shortlist_last_active')?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ($members as $member) : ?>
					<tr>
						<td>
							<?php if ($member['user_type'] == 'guest') : ?>[ <a href="<?=$member_detail_url.'session_id='.$member['session_id']?>"><?=lang('shortlist_guest')?></a> ]
							<?php else : ?>
								<a href="<?=$member['view_member_uri']?>">
									<?php if (isset($member_data[ $member['member_id'] ]['screen_name'])) : ?>
										<?=$member_data[ $member['member_id'] ]['screen_name']?>
									<?php else : ?>
										Member <?=$member['member_id']?>
									<?php endif; ?>
								</a>
							<?php endif; ?>
						</td>
						<td>
							<?php foreach ($member['lists'] as $member_list) : ?>
								<a href="<?=$member_list['detail_url']?>"><?=$member_list['list_title']?></a>
							<?php endforeach; ?>
						</td>
						<td><?=$member['last_activity_since']?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
				<tr class="tbl-action">
					<td colspan="3"><a class="btn action submit" href="<?=$members_uri?>">View All</a></td>
				</tr>
			</table>
<?php
} ?>
		</div>
	</div>
</div>