<div id="shortlist_container" class="box">
	<div class="tbl-ctrls">
		<h1><?=lang('shortlist_settings_title')?></h1>

		<div class="tbl-wrap">
			<table class="data basic">
				<tbody>
					<tr>
						<td>
							<strong>List Pruning</strong><br/>
							Prune lists and items that have been untouhed for a long period.<br />
							This will remove all guest lists older than 7 days
						</td>
						<td>
							<a href="<?=$prune_lists_uri?>" class="btn">Prune Old Lists</a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>