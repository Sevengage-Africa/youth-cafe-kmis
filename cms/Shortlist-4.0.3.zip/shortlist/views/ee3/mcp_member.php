<div id="shortlist_container" class="box">
	<div class="tbl-ctrls">
		<h1><?=lang('shortlist_details_about_this_member')?></h1>

		<div class="tbl-wrap">
			<table class="data basic">
			<tbody>
				<?php if ($user_type == 'session_id'): ?>
					<tr>
						<td width="130"><?=lang('shortlist_guest')?></td>
						<td><p><strong><?=$user_id?></strong></p><p><?=lang('shortlist_guest_detail')?></p></td>
					</tr>
				<?php else : ?>
					<tr>
						<td width="130"><?=lang('screen_name')?></td>
						<td><strong><?=$member_data[$user_id]['screen_name']?></strong></td>
					</tr>
					<tr>
						<td><?=lang('Email')?></td>
						<td><strong><?=$member_data[$user_id]['email']?></strong></td>
					</tr>
					<tr>
						<td><?=lang('member_id')?></td>
						<td><strong><?=$member_data[$user_id]['member_id']?></strong></td>
					</tr>
					<tr>
						<td><?=lang('member_group')?></td>
						<td><strong><?=$member_data[$user_id]['group_id']?></strong></td>
					</tr>
				<?php endif; ?>
			</tbody>
			</table>
		</div>

		<h1><?=lang('shortlist_user_lists')?></h1>
		<?=lang('shortlist_user_lists_count')?> <?=$list_count?> <?=lang_switch('shortlist_list', $list_count)?>
		<br /><br />

		<table class="data">
			<thead>
				<tr style="background-color :transparent">
					<th><?=lang('list_title')?></th>
					<th><?=lang('item_count')?></th>
					<th><?=lang('shortlist_last_active')?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($lists as $list) : ?>
				<tr>
					<td>
						<a href="<?=$list['list_detail_url']?>"><?=$list['list_title']?></a>
					</td>
					<td><?=$list['item_count']?></td>
					<td><?=$list['last_change_since']?></td>
					<td><a href="<?=$list['list_remove_url']?>"><?=lang('shortlist_remove_this_list')?></a></td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>