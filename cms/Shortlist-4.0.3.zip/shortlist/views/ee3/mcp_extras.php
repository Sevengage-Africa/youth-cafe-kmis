<div id="shortlist_container" class="box">
	<div class="tbl-ctrls">
	<?php if ($show_favorites_option) : ?>
		<h1>Import Existing Data from <em>Solspace's Favorites</em></h1>
		<div class="no-results">
			<a href="<?=$import_favs_uri?>" class="btn add">Configure &amp; Import</a>
			Your site appears to be currently using Solspace's Favorites. We can import this existing data over to Shortlist.
		</div>
	<?php endif; ?>

	<?php if ($show_vc_todo_option) : ?>
		<h1>Import Existing Data from <em>VC Todo Addon</em></h1>
		<div class="no-results">
			<a href="<?=$import_custom_uri?>" class="btn add">Configure &amp; Import</a>
			There appears to be data in a format we recognise in the <em>exp_vc_todo</em> table. We can import this data over to Shortlist.
		</div>
	<?php endif; ?>

	<?php if (!$show_vc_todo_option and !$show_favorites_option) : ?>
		<h1>No Imports Available</h1>
		<div class="no-results">
			Shortlist can import data from Solspace's Favorites, and some other custom addons. <br/>
			It doesn't look like you have available data to import right now.<br />
			If you have data you need importing to Shortlist, contact <a href="mailto:support@eeharbor.com?subject=Shortlist Importer Request">Shortlist Support</a> and we'll try and help you out.
		</div>
	<?php endif; ?>
	</div>
</div>