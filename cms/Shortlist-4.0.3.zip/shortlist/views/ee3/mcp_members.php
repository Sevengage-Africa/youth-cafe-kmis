<div id="shortlist_container" class="box">
	<div class="tbl-ctrls">
		<h1><?=$member_count?> <?=lang_switch('shortlist_member', $member_count)?></h1>

		<div class="tbl-wrap">
			<table class="data">
			<thead>
				<tr style="background-color :transparent">
					<th><?=lang('shortlist_member')?></th>
					<th><?=lang('shortlist_member_lists')?></th>
					<th><?=lang('shortlist_last_active')?></th>
				</tr>
			</thead>
			<tbody>

				<?php foreach ($members as $member) : ?>
				<tr>
					<td>
						<?php if ($member['user_type'] == 'guest') : ?>[ <a href="<?=$member_detail_url.'session_id='.$member['session_id']?>"><?=lang('shortlist_guest')?></a> ]
						<?php else : ?><a href="<?=$member['view_member_uri']?>"><?=$member_data[ $member['member_id'] ]['screen_name']?></a><?php endif;?>
					</td>
					<td>
						<?php foreach ($member['lists'] as $member_list) : ?>
							<a href="<?=$member_list['detail_url']?>"><?=$member_list['list_title']?></a>
						<?php endforeach; ?>
					</td>
					<td><?=$member['last_activity_since']?></td>
				</tr>
				<?php endforeach; ?>

			</tbody>
			</table>
		</div>

	<?php if ($has_pagination) : ?>
		<ul class="pagination">
			<li>Page <?=$current_page?> of <?=$total_pages?></li>
			<li>
				<?php if ($prev_link) : ?>
					<a href="<?=$prev_link?>" title="Previous page">Previous</a>
				<?php else : ?>
					<b>Previous</b>
				<?php endif; ?>
			</li>
			<li>
				<?php if ($next_link) : ?>
					<a href="<?=$next_link?>" title="Next page">Next</a>
				<?php else : ?>
					<b>Next</b>
				<?php endif; ?>
			</li>
		</ul>
	<?php endif; ?>
	</div>
</div>