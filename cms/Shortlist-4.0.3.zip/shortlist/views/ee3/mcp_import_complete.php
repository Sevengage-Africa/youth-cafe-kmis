<div id="shortlist_container" class="box">
	<div class="tg" style="">
		<h2>Import Complete</h2>
		<div class="alert">
			The import completed successfully.
		</div>
	</div>
</div>