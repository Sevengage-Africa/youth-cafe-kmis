<?php if (! defined('BASEPATH')) {
    exit('No direct script access allowed');
}


// include_once config file
include_once PATH_THIRD.'shortlist/config.php';
require_once PATH_THIRD.'shortlist/eeharbor.php';

/**
 * Shortlist Extension Class
 *
 * @package         shortlist_ee_addon
 * @author          Tom Jaeger <Tom@EEHarbor.com>
 * @link            http://eeharbor.com/shortlist
 * @copyright       Copyright (c) 2016, Tom Jaeger/EEHarbor
 */

class Shortlist_ext extends \shortlist\Eeharbor_ext
{
    public $name            = SHORTLIST_NAME;
    public $version         = SHORTLIST_VERSION;
    public $description     = 'Shortlist extension';
    public $settings_exist  = false;
    public $docs_url        = SHORTLIST_DOCS;
    public $class_name      = SHORTLIST_CLASS_NAME;
    public $store_modifier_name = 'WishlistID';

    /**
     * Constructor
     *
     * @access      public
     * @param       mixed     Array with settings or FALSE
     * @return      null
     */
    public function __construct($settings = false)
    {
        $this->eeharbor = new \shortlist\EEHarbor;

        // Set Class name
        $this->class_name = ucfirst(get_class($this));

        // Set settings
        $this->settings = $settings;


        // Define the package path
        ee()->load->add_package_path(PATH_THIRD.'shortlist');
          // Load our helper
        ee()->load->helper('Shortlist_helper');
        ee()->lang->loadfile('shortlist');
        // Load base model
        if (!class_exists('Shortlist_model')) {
            ee()->load->library('Shortlist_model');
        }
        if (!isset(ee()->shortlist_core_model)) {
            Shortlist_model::load_models();
        }

       // ee()->load->remove_package_path(PATH_THIRD.'shortlist');
    }

    /**
     * Activate Extension
     */
    public function activate_extension()
    {
        $this->register_extension('channel_entries_row');
        $this->register_extension('store_order_complete_start');
        $this->register_extension('cp_custom_menu');
    }

    /**
     * Update Extension
     */
    public function update_extension($current = FALSE)
    {
        $updated = false;

        if ( ! $current || $current == $this->version)
            return FALSE;

        // add cp_custom_menu hook
        if (version_compare($current, '4.0.0', "<")) {
            $this->register_extension("cp_custom_menu");
            $updated = true;
        }

        if($updated) $this->update_version();
    }

    /**
     * Disable Extension
     */
    public function disable_extension()
    {
        parent::disable_extension();
    }

    /**************************************************\
     ******************* ALL HOOKS: *******************
    \**************************************************/

    public function channel_entries_row($that, $row)
    {
        // has this hook already been called?
        if (isset(ee()->extensions->last_call) && ee()->extensions->last_call) {
            $row = ee()->extensions->last_call;
        }

        if (isset($that->is_shortlist))
        {
            // This is a shortlist row. Get this item's details for this user
            // and add the data as tag data for parsing
            $items = $that->shortlist_items;
            $item = array();

            foreach ($items as $item_row)
            {
                if ($item_row['entry_id'] == $row['entry_id']) {
                    $item = $item_row;
                }
            }

            // Is this an externally sourced entry?
            if ($row['channel_name'] != SHORTLIST_CHANNEL_NAME) {
                $item['is_external'] = false;
            } else {
                $item['is_external'] = true;

                // We need to break up the datablock field for usage in this item
                // Do we need to get the datablock/unique field ids?
                $unique_field_id = $that->shortlist_fields[ SHORTLIST_UNIQUE_FIELD_NAME ];
                $datablock_field_id = $that->shortlist_fields[ SHORTLIST_DATABLOCK_FIELD_NAME ];

                $datablock = unserialize(base64_decode($row[ 'field_id_'. $datablock_field_id]));

                if (is_array($datablock)) {
                    $item = array_merge($item, $datablock);
                }
            }

            // Handle extra fields
            if (isset($item['extra']) and is_array($item['extra'])) {
                foreach ($item['extra'] as $ext_key => $ext_val) {
                    $item['extra:'.$ext_key] = $ext_val;
                }
            }

            // Add our 'added' date to override the entry_date
            $row['entry_real_date'] = $row['entry_date'];
            if (isset($item['added'])) {
                $row['entry_date'] = $item['added'];
            }

            $row = array_merge($row, $item);
        }

        return $row;
    }

    public function store_order_complete_start($order)
    {
        $items = $order->items;
        $shortlist_items = array();

        foreach ($items as $item) {
            $attr = $item->getAttributes();
            $modifiers = $attr['modifiers'];
            if ($modifiers == '') {
                continue;
            }

            $modifiers = json_decode($attr['modifiers'], 1);
            foreach ($modifiers as $mod) {
                if (isset($mod['modifier_name']) && $mod['modifier_name'] == $this->store_modifier_name) {
                    $shortlist_items[] = $mod['modifier_value'];
                }
            }
        }

        if (empty($shortlist_items)) {
            return true;
        }

        // We have some thing we need to update
        $data['store_order_id'] = $order->id;
        $data['store_purchased'] = true;

        ee()->shortlist_item_model->add_extra_data_to_items($shortlist_items, $data);

        return true;
    }

    /**************************************************\
     ******************* ALL ELSE: ********************
    \**************************************************/

    // public function channel_entries_tagdata($tagdata, $row)
    // {
    //     // has this hook already been called?
    //     if (isset(ee()->extensions->last_call) && ee()->extensions->last_call) {
    //         $tagdata = ee()->extensions->last_call;
    //     }

    //     return $tagdata;
    // }

    // public function shortlist_remove($item_id = 0)
    // {
    //     $act_url = $this->_get_action_url('add_to_shortlist');

    //     // Take any and all params and wrap them up neatly
    //     ee()->load->helper('string');

    //     if ($item_id == 0) {
    //         $params = ee()->TMPL->tagparams;
    //     } else {
    //         $params['item_id'] = $item_id;
    //     }

    //     $params = base64_encode(serialize($params));

    //     $act_url .= '&p=' . $params;
    //     $act_url .= '&ret=' . urlencode(ee()->functions->fetch_current_uri());

    //     return $act_url;
    // }

    // public function shortlist_add()
    // {
    //     $act_url = $this->_get_action_url('remove_from_shortlist');

    //     // Take any and all params and wrap them up neatly
    //     ee()->load->helper('string');
    //     $params = base64_encode(serialize(ee()->TMPL->tagparams));

    //     $act_url .= '&p=' . $params;
    //     $act_url .= '&ret=' . urlencode(ee()->functions->fetch_current_uri());
    //     return $act_url;
    // }

    // private function _get_action_url($method_name)
    // {
    //     $action_id    = ee()->db->where(
    //         array(
    //             'class'    => SHORTLIST_CLASS_NAME,
    //             'method'    => $method_name
    //         )
    //     )->get('actions')->row('action_id');

    //     return ee()->functions->fetch_site_index(0, 0) . '?ACT=' . $action_id;
    // }

    // private function _sync_hooks()
    // {
    //     // Get the current hooks list and compare to the actions list up top.
    //     $current_hooks = ee()->db->where('class', $this->class_name)->get('extensions')->result_array();

    //     $hooks = $this->hooks;

    //     foreach ($current_hooks as $hook) {
    //         if (in_array($hook['method'], $hooks)) {
    //             foreach ($hooks as $key => $val) {
    //                 if ($hook['method'] == $val) {
    //                     unset($hooks[ $key ]);
    //                 }
    //             }
    //         }
    //     }


    //     // Now just add the ones that aren't there
    //     foreach ($hooks as $hook) {
    //         ee()->db->insert('extensions', array(
    //             'class'     => $this->class_name,
    //             'method'    => $hook,
    //             'hook'      => $hook,
    //             'priority'  => 10,
    //             'version'   => SHORTLIST_VERSION,
    //             'enabled'   => 'y',
    //             'settings'  => ''
    //         ));
    //     }
    // }
}
