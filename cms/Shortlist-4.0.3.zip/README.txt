-------------------------------------------------------
INFO
-------------------------------------------------------

Shortlist for ExpressionEngine

Date modified    : 2017-10-18
Current version  : 4.0.3

-------------------------------------------------------
REQUIREMENTS
-------------------------------------------------------

1. PHP5

!!!!!!!!!!!!!!!!   WARNING   !!!!!!!!!!!!!!!!

THE SHORTLIST EXTENSION AND MODULE CAN NOT BE INSTALLED
AT THE SAME TIME AS THE NATIVE EE PAGES MODULE!

-------------------------------------------------------
EE2 INSTALLATION
-------------------------------------------------------

1. Make sure the native EE Pages module is not installed, uninstall if not
2. Copy /shortlist/ to /system/expressionengine/third_party/ (or wherever you keep your third-party add-ons)
3. Copy /themes/shortlist/ to /themes/third_party/shortlist/
4. Install the add-on package from Add-ons » Modules

-------------------------------------------------------
EE3 INSTALLATION
-------------------------------------------------------

1. Make sure the native EE Pages module is not installed, uninstall if not
2. Copy /shortlist/ to /system/user/addons/ (or wherever you keep your third-party add-ons)
3. Copy /themes/shortlist/ to /themes/user/shortlist/
4. Install the add-on package from Add-On Manager » Third Party Add-Ons

-------------------------------------------------------
UPGRADING
-------------------------------------------------------

1. Follow the installation instructions for your EE version (i.e. copy files to add-on location)
2. Run the module updater:
    - For EE2: In Add-Ons » Modules, click the "Run Module Updates" button in the upper right
    - For EE3: In Add-On Manager » Third Party Add-Ons, click "Update to X" button

-------------------------------------------------------
DOCUMENTATION
-------------------------------------------------------

https://eeharbor.com/shortlist/documentation

-------------------------------------------------------
CREDIT
-------------------------------------------------------

Tom Jaeger
Email: hello@eeharbor.com
Twitter: @eeharbor

----------------------------------------------
RESTRICTIONS
----------------------------------------------

Unless you have been granted prior, written consent from Tom Jaeger, you may not:

- Reproduce, distribute, or transfer the Software, or portions thereof, to any third party
- Sell, rent, lease, assign, or sublet the Software or portions thereof
- Grant rights to any other person
- GPLv2 software has been used for the javascript in this module and do not carry to those portions