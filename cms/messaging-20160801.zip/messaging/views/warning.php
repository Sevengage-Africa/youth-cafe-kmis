<ul class="messaging_warning" id="messaging_warning">
	<?php foreach ($warnings as $warning): ?>
	<li><?=$warning?></li>
	<?php endforeach; ?>
</ul>