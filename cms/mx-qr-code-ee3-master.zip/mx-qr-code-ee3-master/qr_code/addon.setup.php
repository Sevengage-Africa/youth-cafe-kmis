<?php

return array(
	'author'      => 'Max Lazar',
	'author_url'  => 'https://eec.ms/',
	'name'        => 'MX QR CODE',
	'description' => 'MX QR Code Generator for ExpressionEngine 3',
	'version'     => '3.0.1',
	'namespace'   => 'Mx\Qr_code',
	'settings_exist' => FALSE,
	'plugin.typography' => TRUE
);
