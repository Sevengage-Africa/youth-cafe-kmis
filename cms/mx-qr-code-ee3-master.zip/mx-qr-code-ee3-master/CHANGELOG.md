# Changelog

* **4.0.2** (2016-02-01)
  - EE3 version released to the wild.