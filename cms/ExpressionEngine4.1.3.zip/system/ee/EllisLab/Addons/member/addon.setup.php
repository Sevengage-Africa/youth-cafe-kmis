<?php

return array(
	'author'         => 'EllisLab',
	'author_url'     => 'https://ellislab.com/',
	'name'           => 'Member',
	'description'    => '',
	'version'        => '2.1.0',
	'namespace'      => 'EllisLab\Addons\Member',
	'settings_exist' => FALSE,
	'built_in'       => TRUE
);
