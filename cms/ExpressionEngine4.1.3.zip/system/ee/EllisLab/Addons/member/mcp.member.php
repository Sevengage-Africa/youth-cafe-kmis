<?php
/**
 * ExpressionEngine (https://expressionengine.com)
 *
 * @link      https://expressionengine.com/
 * @copyright Copyright (c) 2003-2018, EllisLab, Inc. (https://ellislab.com)
 * @license   https://expressionengine.com/license
 */

/**
 * Member Management Module control panel
 *
 * Because member management is so tightly, most of the member functions
 * are contained in the core code, rather than this module file.
 */
class Member_mcp {


}
// END CLASS

// EOF
