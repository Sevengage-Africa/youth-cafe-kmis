<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'Rss',
	'description' => '',
	'version'     => '2.0.0',
	'namespace'   => 'EllisLab\Addons\Rss',
	'settings_exist' => FALSE,
);
