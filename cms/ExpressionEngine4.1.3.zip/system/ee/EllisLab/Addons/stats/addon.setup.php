<?php

return array(
	'author'      => 'EllisLab',
	'author_url'  => 'https://ellislab.com/',
	'name'        => 'Stats',
	'description' => '',
	'version'     => '2.0.0',
	'namespace'   => 'EllisLab\Addons\Stats',
	'settings_exist' => FALSE,
);
