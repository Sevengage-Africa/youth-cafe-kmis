<p>Your spam filter has been succesfully trained.</p>
<p>Time <?=$time?></p>
