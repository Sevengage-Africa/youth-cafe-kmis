<div class="modal-wrap spam-modal hidden">
	<div class="modal">
		<div class="col-group">
			<div class="col w-16">
				<a class="m-close" href="#"></a>
				<div class="box">
					<h1>Potential SPAM <span class='type'></span></h1>
					<div class="txt-wrap">
						<ul class="checklist mb">
							<li><b>Date:</b> <span class='date'></span></li>
							<li class="last"><b><abbr title="Internet Protocol">IP</abbr>:</b> <span class='ip'></span></li>
						</ul>
						<div class="content">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
