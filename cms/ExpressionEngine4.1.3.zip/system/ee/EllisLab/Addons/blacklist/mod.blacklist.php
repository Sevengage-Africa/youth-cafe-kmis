<?php
/**
 * ExpressionEngine (https://expressionengine.com)
 *
 * @link      https://expressionengine.com/
 * @copyright Copyright (c) 2003-2018, EllisLab, Inc. (https://ellislab.com)
 * @license   https://expressionengine.com/license
 */

/**
 * Blacklist front end (nada)
 */
class Blacklist {

	var $return_data  = '';

	/**
	  * Constructor
	  */
	function __construct()
	{
		return $this->return_data;
	}

}
// END CLASS

// EOF
